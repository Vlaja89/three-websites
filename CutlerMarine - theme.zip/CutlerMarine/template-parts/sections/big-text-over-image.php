<?php $Title = get_sub_field('big_text_image_title'); ?>
<?php $Image = get_sub_field('big_text_image_img'); ?>

<section id="big-text-over-image">
    <div class="container">

        <div class="big-text-image-box">
            <?php if( $Image ): ?>
                <div class="image">
                    <img src="<?php echo $Image ?>" alt="" class="img-fluid"/>
                </div>
            <?php endif; ?>
            <?php if( $Title ): ?>
                <div class="moving-text">
                    <div class="moving-text-title">
                        <p><?php echo $Title ?> <?php echo $Title ?> <?php echo $Title ?> <?php echo $Title ?> <?php echo $Title ?></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>
</section>

