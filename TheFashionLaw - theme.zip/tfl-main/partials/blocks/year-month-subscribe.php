<?php

    // Year Month Subscribe Block
    $className = 'year_month_subscribe';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $SmallTitle   = get_field('small_title');
    $BigTitle     = get_field('big_title');
    $Description  = get_field('description');


?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
            
            <div class="year-month-box">
                
                <div class="col-lg-3 col-md-12 col-sm-12">

                    <div class="text">
                        <?php if ( $SmallTitle ) : ?>
                            <div class="small-title">
                                <p class="category-article"><?php echo $SmallTitle; ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ( $BigTitle ) : ?>
                            <div class="big-title">
                                <h1><?php echo $BigTitle; ?></h1>
                            </div>
                        <?php endif; ?>
                    
                        <?php if ( $Description ) : ?>
                            <div class="description">
                                <?php echo $Description; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Tabs -->
                    <div class="main-tabs">
                        <?php if( have_rows('year') ): ?>
                            <a href="#" class="tab category-article active" data-toggle-target=".year-content">Yearly</a>
                        <?php endif; ?>
                        <?php if( have_rows('month') ): ?>
                            <a href="#" class="tab category-article" data-toggle-target=".month-content">monthly</a>
                        <?php endif; ?>
                    </div>
                    <!-- End Tabs -->

                    <!-- Buttons -->
                    <div class="main-btns d-991-none">
                        <?php if( get_field('buttons') ): ?>
                            <div class="btns-title">
                                <p>more about our plans</p>
                            </div>
                            <?php if( have_rows('buttons') ): ?> 
                                <?php while( have_rows('buttons') ) : the_row(); ?>

                                    <div class="single-btn">
                                        <?php
                                            $link = get_sub_field('btn_url');
                                            if( $link ):
                                                $link_url = $link['url'];
                                                $link_title = $link['title'];
                                        ?>
                                        <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                            <?php echo esc_html( $link_title ); ?>
                                            <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                        </button>
                                        <?php endif; ?>
                                    </div>

                                <?php endwhile; ?>
                            <?php endif;?>
                        <?php endif; ?>
                    </div>
                    <!-- End Buttons -->

                </div>

                <div class="col-lg-9 col-md-12 col-sm-12">
                    <!-- Year -->
                    <?php if( get_field('year') ): ?>
                        <div class="tab-content year-content active">
                            <?php if( have_rows('year') ): ?> 
                                <?php while( have_rows('year') ) : the_row(); ?>
                                    <div class="year-month-single-box">
                                        <div class="content">
                                            <div class="top-title">
                                                <p class="category-article"><?php the_sub_field('year_small_title'); ?></p>
                                            </div>
                                            <div class="price">
                                                <p><?php the_sub_field('year_price'); ?> <span class="category-article">/ <?php the_sub_field('year_price_period'); ?></span></p>
                                            </div>
                                            <div class="description">
                                                <?php the_sub_field('year_description'); ?>
                                            </div>
                                            <div class="btn">
                                                <?php
                                                    $link = get_sub_field('year_btn_url');
                                                        if( $link ):
                                                            $link_url = $link['url'];
                                                            $link_title = $link['title'];
                                                    ?>
                                                    <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                                        <?php echo esc_html( $link_title ); ?>
                                                        <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="features">
                                            <p class="category-article">features</p>
                                            <?php if( have_rows('year_features') ): ?> 
                                                <?php while( have_rows('year_features') ) : the_row(); ?>

                                                    <div class="single-feature">
                                                        <div class="icon">
                                                            <?php the_sub_field('year_feature_icon'); ?>
                                                        </div>
                                                        <div class="description">
                                                            <?php the_sub_field('year_features_description'); ?>
                                                        </div>
                                                    </div>

                                                <?php endwhile; ?>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif;?>
                        </div>
                    <?php endif; ?>

                    <!-- Month -->
                    <?php if( get_field('month') ): ?>
                        <div class="tab-content month-content">
                            <?php if( have_rows('month') ): ?> 
                                <?php while( have_rows('month') ) : the_row(); ?>
                                    <div class="year-month-single-box">
                                        <div class="content">
                                            <div class="top-title">
                                                <p class="category-article"><?php the_sub_field('month_small_title'); ?></p>
                                            </div>
                                            <div class="price">
                                                <p><?php the_sub_field('month_price'); ?> <span class="category-article">/ <?php the_sub_field('month_price_period'); ?></span></p>
                                            </div>
                                            <div class="description">
                                                <?php the_sub_field('month_description'); ?>
                                            </div>
                                            <div class="btn">
                                                <?php
                                                    $link = get_sub_field('month_btn_url');
                                                        if( $link ):
                                                            $link_url = $link['url'];
                                                            $link_title = $link['title'];
                                                    ?>
                                                    <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                                        <?php echo esc_html( $link_title ); ?>
                                                        <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="features">
                                            <p class="category-article">features</p>
                                            <?php if( have_rows('month_features') ): ?> 
                                                <?php while( have_rows('month_features') ) : the_row(); ?>

                                                    <div class="single-feature">
                                                        <div class="icon">
                                                            <?php the_sub_field('month_feature_icon'); ?>
                                                        </div>
                                                        <div class="description">
                                                            <?php the_sub_field('month_features_description'); ?>
                                                        </div>
                                                    </div>

                                                <?php endwhile; ?>
                                            <?php endif;?>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif;?>
                        </div>
                    <?php endif; ?>
                </div>

                
                <!-- Buttons Mobile -->
                <div class="main-btns d-991-block">
                    <?php if( get_field('buttons') ): ?>
                        <div class="btns-title">
                            <p>more about our plans</p>
                        </div>
                        <?php if( have_rows('buttons') ): ?> 
                            <?php while( have_rows('buttons') ) : the_row(); ?>

                                <div class="single-btn">
                                    <?php
                                        $link = get_sub_field('btn_url');
                                        if( $link ):
                                            $link_url = $link['url'];
                                            $link_title = $link['title'];
                                    ?>
                                    <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                        <?php echo esc_html( $link_title ); ?>
                                        <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                    </button>
                                    <?php endif; ?>
                                </div>

                            <?php endwhile; ?>
                        <?php endif;?>
                    <?php endif; ?>
                </div>
                <!-- End Buttons Mobile -->
                
            </div>

        </div>
    </div>
</section>