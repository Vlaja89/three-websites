<!DOCTYPE html>
<html lang="en" dir="ltr" id="modernizrcom" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<title><?php if(is_home()) bloginfo('name'); else wp_title(''); ?></title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
    <link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
    <link rel="alternate" type="application/atom+xml" title="Atom 1.0" href="<?php bloginfo('atom_url'); ?>" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

    <script type="text/javascript">var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";</script>
	
    <?php wp_head(); ?>

    <!-- EV CSS and JS -->
    <link rel="stylesheet" href="/evolok/ev-widgets/prefixed-bootstrap.css">
    <link rel="stylesheet" href="/evolok/ev-widgets/ev-widgets.min.css?ver=3.22.0-20220707">
    <link rel="stylesheet" href="/evolok/ev-ad/ev-em.min.css?ver=3.4.1">
    <link rel="stylesheet" href="/evolok/ev-custom.css?ver=0.3">
    <script defer src="/evolok/ev-widgets/ev-widgets.min.js?ver=3.22.0-20221213"></script>
    <script defer src="/evolok/ev-dab/ev-dab.min.js?ver=1.3.1"></script>
    <script defer src="/evolok/ev-ad/ev-em.min.js?ver=3.4.3"></script>
    <script defer src="/evolok/ev-custom.js?ver=0.6"></script>

</head>

<body <?php body_class(); ?>>

	<header class="home-header">
        <div class="header-top d-767-block">
            <div class="container-width">
                <div class="header-top-box">
                    <div class="main-menu">
                        <?php
                            if (has_nav_menu('register_menu')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'register_menu',
                                    'menu_class' => ' ',
                                    'container' => 'ul'
                                ));
                            }
                        ?>
                    </div>
                    <div class="search-icon">
                        <div class="toggle">
                            <img src="<?php echo get_theme_file_uri('./assets/images/search-white.svg') ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-width">
            <div class="header-box">

                <div class="logo">
                    <?php the_custom_logo(); ?>
                </div>
                
                <div class="header-content">
                    <div class="main-menu home-cat-menu">
                        <?php
                            if (has_nav_menu('category_menu')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'category_menu',
                                    'menu_class' => ' ',
                                    'container' => 'ul'
                                ));
                            }
                        ?>
                    </div>

                    <div class="main-menu d-767-none">
                        <?php
                            if (has_nav_menu('register_menu')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'register_menu',
                                    'menu_class' => ' ',
                                    'container' => 'ul'
                                ));
                            }
                        ?>
                    </div>

                    <!-- Search -->
                    <div id="target" class="header-search-form">
                        <p class="close-form">X</p>
                        <?php get_search_form(); ?>
                    </div>

                    <div class="search-icon d-767-none">
                        <div class="toggle">
                            <img src="<?php echo get_theme_file_uri('./assets/images/search.svg') ?>" alt="">
                        </div>
                    </div>
                    <!-- End Search -->

                    <!-- Toggle Menu -->
                    <div id="menuToggle">
                        <input type="checkbox" />
                        <span></span>
                        <span></span>
                        <span></span>
                        <ul id="menu">

                            <div class="logo mob-logo">
                                <?php the_custom_logo(); ?>
                            </div>

                            <?php
                                if (has_nav_menu('category_menu')) {
                                    wp_nav_menu(array(
                                        'theme_location' => 'category_menu',
                                        'menu_class' => ' ',
                                        'container' => 'ul'
                                    ));
                                }
                            ?>
                            
                            <?php
                                if (has_nav_menu('mobile_menu')) {
                                    wp_nav_menu(array(
                                        'theme_location' => 'mobile_menu',
                                        'menu_class' => ' ',
                                        'container' => 'ul'
                                    ));
                                }
                            ?>
                            
                            <div class="social-media">
                                <?php if( have_rows('social_media', 'option') ):?>
                                    <?php while( have_rows('social_media', 'option') ) : the_row();?>

                                       <div class="single-media">
                                            <a href="<?php the_sub_field('social_media_url', 'option'); ?>" target="_blank">
                                                <img src="<?php the_sub_field('social_media_icon', 'option'); ?>" alt="">
                                            </a>
                                       </div>

                                    <?php endwhile;?>
                                <?php endif; ?>
                            </div>

                        </ul>
                    </div>
                    <!-- End Toggle Menu -->

                </div>

            </div>
        </div>
    </header>

    <div id="main">

    