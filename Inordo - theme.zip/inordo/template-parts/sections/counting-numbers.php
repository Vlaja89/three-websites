<section id="counting-numbers">
    <div class="container">

        <div class="number-boxes">
            <?php if( have_rows('counting__numbers') ): ?>
                <?php while( have_rows('counting__numbers') ): the_row(); ?>
                    <div class="single-number-box">
                        <div class="title">
                            <p><?php the_sub_field('counting__numbers_title') ?></p>
                        </div>
                        <div class="number">
                            <p class="count"><?php the_sub_field('counting__numbers_numb') ?></p>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>

    </div>
</section>

