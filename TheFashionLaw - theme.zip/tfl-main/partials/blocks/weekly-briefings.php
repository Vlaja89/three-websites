<?php

    // Weekly Briefings Block
    $className = 'weekly_briefings';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('weekly_briefings_title');
    $text       = get_field('weekly_briefings_description');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
        
        <div class="row-width">
            <div class="text col-width">
                <?php if ($title) : ?>
                    <h1><?php echo $title; ?></h1>
                <?php endif; ?>

                <?php if ($text) : ?>
                    <h2><?php echo $text; ?></h2>
                <?php endif; ?>
            </div>

            <div class="content col-width">
            <?php
                $args = array(
                    'post_type'      => 'page',
                    'posts_per_page' => -1,
                    'meta_query'     => array(
                        array(
                            'key'     => 'page_type',
                            'value'   => 'weekly-briefings',
                            'compare' => 'LIKE'
                        )
                    )
                );

                $query = new WP_Query($args);

                if ($query->have_posts()) {
                    // Create an array to store posts by year and month
                    $posts_by_year_month = array();

                    while ($query->have_posts()) {
                        $query->the_post();
                        global $post;

                        // Get the year and month of the current post
                        $post_year = get_the_date('Y');
                        $post_month = get_the_date('F');

                        // Add the post to the respective year and month array
                        if (!isset($posts_by_year_month[$post_year])) {
                            $posts_by_year_month[$post_year] = array();
                        }
                        if (!isset($posts_by_year_month[$post_year][$post_month])) {
                            $posts_by_year_month[$post_year][$post_month] = array();
                        }
                        $posts_by_year_month[$post_year][$post_month][] = $post;
                    }

                    // Loop through the posts by year and month and display them
                    foreach ($posts_by_year_month as $year => $months) { ?>
                        <div class="post-year-box">
                            <h2><strong><?php echo $year ?></strong></h2>
                            <?php foreach ($months as $month => $posts) { ?>
                                <div class="post-month-box">
                                    <h6 class="toggle-month showBtn"><?php echo $month ?></h6>
                                    <div class="month-posts hideme">
                                        <?php foreach ($posts as $post) {
                                            setup_postdata($post);
                                            ?>
                                                <h3>
                                                    <a href="<?php echo get_permalink($post->ID) ?>">
                                                    <?php echo get_the_date('F j, Y'); ?>
                                                    </a>
                                                </h3>
                                            <?php
                                        } ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    <?php }
                } wp_reset_postdata();
                ?>

           </div>
        </div>

        </div>
    </div>
</section>