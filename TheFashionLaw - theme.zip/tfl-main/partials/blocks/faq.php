<?php

    // FAQ Block
    $className = 'main_faq';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('faq_title');
    $Description      = get_field('faq_description');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div id="faq-section"></div>
    <div class="wrapper">
        <div class="holder">

            <div class="faq-box">
                <div class="col-lg-3 col-md-12 col-sm-12">
                    <div class="content">
                        <div class="text">
                            <?php if ($Description) : ?>
                                <h2 class="general"><?php echo $title; ?></h2>
                            <?php endif; ?>
                        </div>
                        <div class="descripiton">
                            <?php if ($Description) : ?>
                                <?php echo $Description; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-12 col-sm-12">
                    <div class="faq">
                        <?php if( have_rows('faq') ): ?> 
                            <?php while( have_rows('faq') ) : the_row(); ?>

                                <div class="single-faq">

                                    <div class="showBtn">
                                        <div class="number">
                                            <p class="category-article"><?php echo str_pad(strval(get_row_index()), 2, '0', STR_PAD_LEFT); ?></p>
                                        </div>
                                        <div class="question">
                                            <h3><?php the_sub_field('faq_question'); ?></h3>
                                        </div>
                                    </div>
                                    <div class="hideme">
                                        <div class="answer">
                                            <?php the_sub_field('faq_answer'); ?>
                                        </div>
                                    </div>
                                
                                </div>

                            <?php endwhile; ?>
                        <?php endif;?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>