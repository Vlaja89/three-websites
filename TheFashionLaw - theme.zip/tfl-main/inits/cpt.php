<?php 
/**
 * Custom Post Types
 *
 * @package starter_wp_theme
 */


// Custom post type People
 function create_daily_links_cpt(){
     $labels = array(
         'name'                  => __('Daily Links'),
         'singular_name'         => __('Daily Links'),
         'add_new'               => __('Add Daily Link'),
         'add_new_item'          => __('Add New Daily Link'),
         'edit_item'             => __('Edit Daily Link'),
         'new_item'              => __('New Daily Link'),
         'all_items'             => __('All Daily Links'),
         'view_item'             => __('View Daily Links'),
         'search_items'          => __('Search Daily Links'),
         'not_found'             => __('No Daily Links found'),
         'not_found_in_trash'    => __('No Daily Links found in the Trash'),
         'menu_name'             => 'Daily Links',
         );
     $args = array(
         'labels'        => $labels,
         'public'        => true,
         'menu_position' => 24,
         'menu_icon'     => __( 'dashicons-admin-links' ),
         'supports'      => array('title', 'thumbnail', 'editor'),
 		 'show_in_rest' 	=> true,
         'taxonomies'  => array( 'topics', 'category' ),
         'exclude_from_search' => false
     );
     register_post_type('daily-links', $args);
 }
 add_action('init', 'create_daily_links_cpt');