<?php $StickyTitle = get_sub_field('sticky_title'); ?>
<?php $StickyContent = get_sub_field('sticky_description'); ?>

<section id="sticky-menu-section">

    <div class="sticky-banner">
        <div class="container">
            <!-- Links with Section -->
            <div class="row">
                <div class="col-lg-6 col-md-10 col-sm-12">
                    <?php if( $StickyTitle ): ?>
                        <div class="title">
                            <h2><?php echo $StickyTitle ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if( $StickyContent ): ?>
                        <div class="description">
                            <?php echo $StickyContent ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div id="btns-header">
            <div class="container">
                <!-- Button -->
                <?php if( get_sub_field('sticky_buttons') ): ?>
                    <div class="sticky-btns">
                        <?php if( have_rows('sticky_buttons') ): ?>
                            <?php $linkNumb = 1 ?>
                            <?php while( have_rows('sticky_buttons') ): the_row(); ?>
                                <p><a href="#section-<?php echo $linkNumb; ?>" class="custom-link"><?php the_sub_field('sticky_btn_name'); ?></a></p>
                            <?php $linkNumb++; endwhile; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <!-- End Button -->
            </div>
        </div>
    </div>

        <!-- Full Sections -->
        <div class="sticky-sections">
            <div class="container">
                <?php if( get_sub_field('sticky_sections') ): ?>
                    <?php if( have_rows('sticky_sections') ): ?>
                        <?php $secNumb = 1 ?>
                        <?php while( have_rows('sticky_sections') ): the_row(); ?>

                            <div class="single-sticky-section">
                                <div id="section-<?php echo $secNumb; ?>" class="section-position"></div>
                                <div class="row flex-wrap align-items-center" id="tab-<?php echo $secNumb; ?>">

                                    <?php $Icon = get_sub_field('sticky_section_icon'); ?>
                                    <?php $Title = get_sub_field('sticky_section_title'); ?>
                                    <?php $Content = get_sub_field('sticky_section_description'); ?>
                                    <?php $Image = get_sub_field('sticky_image'); ?>

                                    <div class="col-lg-6 col-md-12 col-sm-12 content-order">
                                        <div class="content">
                                            <?php if( $Icon ): ?>
                                                <div class="icon">
                                                    <img src="<?php echo $Icon ?>" alt="" class="img-fluid"/>
                                                </div>
                                            <?php endif; ?>
                                            <?php if( $Title ): ?>
                                                <div class="title">
                                                    <h3><?php echo $Title ?></h3>
                                                </div>
                                            <?php endif; ?>
                                            <?php if( $Content ): ?>
                                                <div class="description">
                                                    <?php echo $Content ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if( get_sub_field('sticky_section_btn') ): ?>
                                            <!-- Button -->
                                                <?php 
                                                    $link = get_sub_field('sticky_section_btn');
                                                    if( $link ): 
                                                        $link_url = $link['url'];
                                                        $link_title = $link['title'];
                                                        ?>
                                                        <button type="button" class="red-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';"><?php echo esc_html( $link_title ); ?></button>
                                                    <?php endif; ?>
                                                <!-- End Button -->
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <?php if( $Image ): ?>
                                        <div class="col-lg-6 col-md-12 col-sm-12 image-order">
                                            <div class="image">
                                                <img src="<?php echo $Image ?>" alt="" class="img-fluid"/>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                        <?php $secNumb++; endwhile; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

</section>