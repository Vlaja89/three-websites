<?php $Title = get_sub_field('title_testimonials_title'); ?>

<div id="title-testimonial">
    <div class="container">

        <div class="row flex wrap align-items-center">
            <div class="col-lg-6 col-md-12 col-sm-12">

                <?php if( $Title ): ?>
                    <div class="title big-title">
                        <h2><?php echo $Title ?></h2>
                    </div>
                <?php endif; ?>

            </div>
            <div class="offset-lg-1 col-lg-5 col-md-12 col-sm-12">
                
                <div class="testimonials-slider">
                    <?php
                        $testimonial = get_sub_field('title_testimonials_test');
                        if( $testimonial ): ?>
                            <?php foreach( $testimonial as $post ): 

                                // Setup this post for WP functions (variable must be named $post).
                                setup_postdata($post); ?>
                                    <div class="single-testimonial-box">
                                        <div class="testimonial-icon">
                                            <img src="<?php echo get_theme_file_uri('./dist/img/quote.svg') ?>" alt="">
                                        </div>
                                        <div class="testimonial-title">
                                            <p><?php the_field('testimonial_description'); ?></p>
                                        </div>
                                        <div class="content">
                                            <div class="testimonial-img">
                                                <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                            </div>
                                            <div class="info">
                                                <div class="testimonial-name">
                                                    <p><?php the_title(); ?></p>
                                                </div>
                                                <div class="testimonial-position">
                                                    <p><?php the_field('testimonial_position'); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                            <?php endforeach; ?>
                        <?php 
                        // Reset the global post object so that the rest of the page works correctly.
                        wp_reset_postdata(); ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        
    </div>
</div>