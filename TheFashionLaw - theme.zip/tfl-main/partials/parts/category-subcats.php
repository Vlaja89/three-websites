<?php 
    $image      = get_field('image');
    $subtitle   = get_field('subtitle');
    $title      = get_field('title');
    $text       = get_field('text');
    // Neka bude ovako za sada, verovatno ce se promeniti u relationship
?>

<section class="subcategory-posts">
    <div class="wrapper">
        <div class="holder">
            <div class="highlight">
                <h5 class="highlighted-title">Subcategories</h5>
                <ul class="filter-list">
                    <li>
                        <a href="#">all</a>
                    </li>
                    <li>
                        <a href="/deals">deals</a>
                    </li>
                    <li>
                        <a href="/fashion">fashion</a>
                    </li>
                </ul>
            </div>
            <div class="results-holder">

                <div class="filter-dd">
                    <div class="filter-dd__title">
                        <span>Filter</span>
                        <span class="filter-icon"></span>
                    </div>
                    <div class="filter-dd__content">
                        <ul class="filter-list">
                            <li>
                                <a href="#">all</a>
                            </li>
                            <li>
                                <a href="/deals">deals</a>
                            </li>
                            <li>
                                <a href="/fashion">fashion</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <ul class="posts-list">
                    <li>
                        <div class="top">
                            <div class="category">
                                <?php 
                                    $categories = get_the_category();
                                    if ( ! empty( $categories ) ) {
                                        echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                                    }
                                ?>
                                | time read
                            </div>
                            <img src="http://localhost:8888/wordpress/wp-content/uploads/2020/10/featured-post-1.jpg" alt="">
                        </div>
                        <article>
                            <h4>Burberry Reports $1.6 Billion in H1 Revenue, Reveals Accessories-Centric Plan</h4>
                            <div class="meta">
                                <?php get_the_date( 'F j, Y' ) ?> - By <?php the_author(); ?>
                            </div>
                        </article>
                    </li>
                </ul>

                <div class="pagination">
                    <ul>
                        <li>
                            <a href="#" class="prev">
                                <img src="#" alt="Prev Icon">
                            </a>
                        </li>
                        <li>
                            <a href="#" class="active">1</a>
                        </li>
                        <li>
                            <a href="#">2</a>
                        </li>
                        <li>
                            <a href="#" class="next">
                                <img src="#" alt="Next Icon">
                            </a>
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section><!-- Subcategory Posts -->