<?php get_header(); ?>

<div id="wrapp">

    <?php if( have_rows('content') ):
        while ( have_rows('content') ) : the_row(); ?>

            <?php  if( get_row_layout() == 'main_banner' ): ?>
            <!-- Main Banner -->
            
                <?php get_template_part('template-parts/banners/main-banner'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'portfolio' ): ?>
            <!-- Portfolio -->
            
                <?php get_template_part('template-parts/sections/portfolio'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'quote' ): ?>
            <!-- Quote -->
            
                <?php get_template_part('template-parts/sections/quote'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'moving_track' ): ?>
            <!-- Moving Track -->
            
                <?php get_template_part('template-parts/sections/moving-track'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'our_service' ): ?>
            <!-- Our Services -->
            
                <?php get_template_part('template-parts/sections/our-service'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'posts' ): ?>
            <!-- Posts -->
            
                <?php get_template_part('template-parts/sections/posts'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'contact_form_section' ): ?>
            <!-- Contact Form -->
            
                <?php get_template_part('template-parts/options/contact-form'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'our_works' ): ?>
            <!-- Our Works -->

                <?php get_template_part('template-parts/sections/our-works'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'banner_content_image' ): ?>
            <!-- Banner Content Image -->

                <?php get_template_part('template-parts/banners/banner-content-image'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'counting_numbers' ): ?>
            <!-- Counting Numbers -->

                <?php get_template_part('template-parts/sections/counting-numbers'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'content_with_list' ): ?>
            <!-- Content with List -->

                <?php get_template_part('template-parts/sections/content-with-list'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'gallery_box' ): ?>
            <!-- Gallery Box -->

                <?php get_template_part('template-parts/sections/gallery-box'); ?>
                
            <?php endif; ?>

            <?php  if( get_row_layout() == 'title_and_testimonials' ): ?>
            <!-- Title and TEstimonials -->

                <?php get_template_part('template-parts/sections/title-and-testimonials'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'big_center_title' ): ?>
            <!-- Big Center Title -->

                <?php get_template_part('template-parts/sections/big-center-title'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'banner_big_center_title' ): ?>
            <!-- Banner Big Center Title -->

                <?php get_template_part('template-parts/banners/banner-big-center-title'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'images_and_content' ): ?>
            <!-- Image and Content -->

                <?php get_template_part('template-parts/sections/images-content'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'jobs' ): ?>
            <!-- Jobs -->

                <?php get_template_part('template-parts/sections/jobs'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'main_contact_form' ): ?>
            <!-- Main Contact Form -->

                <?php get_template_part('template-parts/sections/main-contact-form'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'banner_title_quote' ): ?>
            <!-- Banner Title and Quote -->

                <?php get_template_part('template-parts/banners/banner-title-quote'); ?>
                
            <?php endif; ?>
            
            <?php  if( get_row_layout() == 'blog_posts' ): ?>
            <!-- Blog Posts -->

                <?php get_template_part('template-parts/sections/blog-posts'); ?>
                
            <?php endif; ?>

        <?php  endwhile; ?>
        <?php else : ?>
    <?php endif; ?>

</div>

     
<?php get_footer(); ?>