<?php

    // Title Description Block
    $className = 'text_description';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $Title      = get_field('title');
    $Descrition       = get_field('description');
?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">
           <?php if ($Title) : ?>
                <div class="title">
                    <h2 class="general"><?php echo $Title; ?></h2>
                </div>
            <?php endif; ?>
            <?php if ($Descrition) : ?>
                <div class="description">
                    <?php echo $Descrition; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>