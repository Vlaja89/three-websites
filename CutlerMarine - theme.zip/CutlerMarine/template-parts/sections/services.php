<?php $Title = get_sub_field('services_title'); ?>
<?php $Content = get_sub_field('services_description'); ?>

<section id="services">
    <div class="container">
        <div class="row flex-wrap align-items-center">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <?php if( $Title ): ?>
                    <div class="title">
                        <h3><?php echo $Title ?></h3>
                    </div>
                <?php endif; ?>
                <?php if( $Content ): ?>
                    <div class="description">
                        <?php echo $Content ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="service-slider services-box">
            <?php
                $services = get_sub_field('service');
                if( $services ): ?>
                    <?php foreach( $services as $post ): 

                        // Setup this post for WP functions (variable must be named $post).
                        setup_postdata($post); ?>
                        <div class="single-service-box">
                            <div class="service-img">
                                <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                            </div>
                            <div class="service-info">
                                <div class="service-title">
                                    <h4><?php the_title(); ?></h4>
                                </div>
                                <div class="service-desc">
                                    <p><?php the_excerpt() ?></p>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>
                <?php 
                // Reset the global post object so that the rest of the page works correctly.
                wp_reset_postdata(); ?>
            <?php endif; ?>
    </div>
            
    </div>
</section>