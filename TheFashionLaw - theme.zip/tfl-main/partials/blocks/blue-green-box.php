<?php

    // Blue Green Box Block
    $className = 'blue_green';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('blue_green_title');

    // Editor in chief. Ovo cemo naknadno da ubacimo za width blokova
?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">

            <div class="blue-green-box">
                <div class="text">
                    <?php if ($title) : ?>
                        <div class="big-title">
                            <h4><?php echo $title; ?></h4>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="link">
                    <?php
                        $link = get_field('blue_green_url');
                        if( $link ):
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                    ?>
                    <h3><a href="<?php echo esc_url( $link_url ); ?>"><?php echo esc_html( $link_title ); ?></a></h3>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</section><!-- Text & Image Columns -->
