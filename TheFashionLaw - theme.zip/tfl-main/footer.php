	</div>
	
	<footer>
		<div class="container-width">
			<div class="footer-box">

				<div class="footer-box-logo">
					<div class="footer-logo">
						<img src="<?php the_field('footer_logo', 'option'); ?>" alt="" class="img-fluid">
					</div>
				</div>

				<div class="footer-content">

					<div class="footer-content-box">
						<div class="footer-desc">
							<h2><?php the_field('footer_description', 'option'); ?></h2>
							<div class="newsletter">
								<p class="category-article">stay up to date</p>
								<?php echo do_shortcode('[gravityform id="1" title="true"]'); ?>
							</div>
						</div>

						<div class="footer-menu">
							<p class="category-article">Categories</p>
							<?php
								if (has_nav_menu('category_menu')) {
									wp_nav_menu(array(
										'theme_location' => 'category_menu',
										'menu_class' => ' ',
										'container' => 'ul'
									));
								}
							?>
						</div>
						
						<div class="footer-menu">
							<p class="category-article">About</p>
							<?php
								if (has_nav_menu('about_menu')) {
									wp_nav_menu(array(
										'theme_location' => 'about_menu',
										'menu_class' => ' ',
										'container' => 'ul'
									));
								}
							?>
							<div class="footer-media d-991-block">
								<p class="category-article">Follow</p>
								<?php if( have_rows('social_media', 'option') ):?>
									<?php while( have_rows('social_media', 'option') ) : the_row();?>

										<div class="single-media">
											<a href="<?php the_sub_field('social_media_url', 'option'); ?>" target="_blank">
												<img src="<?php the_sub_field('social_media_icon_white', 'option'); ?>" alt="">
											</a>
										</div>

									<?php endwhile;?>
								<?php endif; ?>
							</div>
						</div>

						<div class="footer-media d-991-none">
							<p class="category-article">Follow</p>
							<?php if( have_rows('social_media', 'option') ):?>
								<?php while( have_rows('social_media', 'option') ) : the_row();?>

									<div class="single-media">
										<a href="<?php the_sub_field('social_media_url', 'option'); ?>" target="_blank"><?php the_sub_field('social_media_title', 'option'); ?></a>
									</div>

								<?php endwhile;?>
							<?php endif; ?>
						</div>
					</div>

					<div class="copyright">
						<?php the_field('copyright', 'option'); ?>
						<div class="copyright-menu">
							<?php
								if (has_nav_menu('terms_menu')) {
									wp_nav_menu(array(
										'theme_location' => 'terms_menu',
										'menu_class' => ' ',
										'container' => 'ul'
									));
								}
							?>
						</div>
					</div>
				</div>

			</div>
		</div>
	</footer>
	
	<?php wp_footer(); ?>

</body>
</html>