<?php get_header(); ?>

<?php 
    $page_type = get_field('page_type');
    $page_type_value = $page_type['value'];
?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

    <?php
    switch ($page_type_value) {

        case "null":
            echo '<div class="null-page default-post-style container-width">';
            the_content();
            echo '</div>';
            break;

        case 'proprietary-data-sets':
            echo '<div class="proprietary-data-sets-page default-post-style section-width">
					<div class="small-title">
						<p class="category-article">Data Sets</p>
					</div>
					';
            the_content();
            echo '</div>';
            break;

        case 'deep-dives':
            echo '<div class="deep-dives-page default-post-style section-width">
					<div class="small-title">
						<p class="category-article">Deep Dives</p>
					</div>
				';
            the_content();
            echo '</div>';
            break;

        case 'weekly-briefings':
            echo '<div class="weekly-briefings-page default-post-style section-width">';
            the_content();
            echo '</div>';
            break;

        case 'case-documentation':
            echo '<div class="case-documentation-page container-width">';
            the_content();
            echo '</div>';
            break;

        case 'reports-trackers':
            echo '<div class="reports-trackers-page container-width">';
            the_content();
            echo '</div>';
            break;

        case 'case-briefs':
            echo '<div class="case-briefs-page default-post-style section-width">
                    <div class="small-title">
						<p class="category-article">Case Briefs</p>
					</div>
                    ';
            echo '<h1>' . get_the_title() . '</h1>';
            the_content();
            echo '</div>';
            break;
            
        case 'case-studies':
            echo '<div class="case-studies-page default-post-style section-width">';
            the_content();
            echo '</div>';
            break;

        case 'topics-of-interest':
            echo '<div class="topics-of-interest-page default-post-style section-width">';
            the_content();
            echo '</div>';
            break;
			
        case 'ttab-tracker':
            echo '<div class="ttab-tracker-page default-post-style section-width">';
            the_content();
            echo '</div>';
            break;
    }
    ?>

    <?php endwhile; endif; ?>

<?php get_footer(); ?>
