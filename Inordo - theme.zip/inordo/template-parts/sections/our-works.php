<?php $Title = get_sub_field('works_main_title'); ?>

<div id="our-works">

    <div class="container">

        <div class="main-title">
            <?php if( $Title ): ?>
                <div class="title">
                    <h1><?php echo $Title ?></h1>
                </div>
            <?php endif; ?>
        </div>

            <?php
                $works = get_sub_field('our_works');
                if( $works ): ?>
                    <?php foreach( $works as $post ): 

                        // Setup this post for WP functions (variable must be named $post).
                        setup_postdata($post); ?>
                        <div class="work-box row flex-wrap align-items-center">
                            <div class="col-lg-6 col-md-12 col-sm-12 section-order-1">
                                <div class="works-content">
                                    <div class="d-flex align-items-center">
                                        <div class="portfolio-service box-element">
                                            <p><?php the_field('portfolio_service'); ?></p>
                                        </div>
                                        <div class="date">
                                            <p><?php echo get_the_date(); ?></p>
                                        </div>
                                    </div>
                                    <div class="portfolio-name big-title">
                                        <h3><?php the_title(); ?></h3>
                                    </div>
                                    <div class="excerpt">
                                        <p><?php echo substr(get_the_excerpt(), 0,210)." ..." ?></p>
                                    </div>
                                    <div class="btn-box">
                                        <button type="button" class="empty-custom-btn" onclick="location.href='<?php the_permalink() ?>';">
                                            View Project
                                        </button>
                                        <img src="<?php echo get_theme_file_uri('./dist/img/circle-grey-arrow-right.svg') ?>" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-12 col-sm-12 section-order-2">
                                <div class="works-img">
                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>
                <?php 
                // Reset the global post object so that the rest of the page works correctly.
                wp_reset_postdata(); ?>
            <?php endif; ?>
        
    </div>

</div>