<?php 
    $post_id = get_the_ID();
    $primary_category = get_primary_category($post_id);
    
    if ($primary_category) {
        $category_name = $primary_category->name;
        $category_link = get_term_link($primary_category);
        
        echo '<a href="' . $category_link . '">' . $category_name . '</a>';
    }
?>