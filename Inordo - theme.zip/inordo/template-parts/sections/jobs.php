<?php $Title = get_sub_field('jobs_main_title'); ?>
<?php $Description = get_sub_field('jobs_description'); ?>

<section id="jobs">
    <div class="container">

        <div class="row flex-wrap align-items-start">
            <div class="col-lg-5 col-md-12 col-sm-12">

                <div class="main-title">
                    <?php if( $Title ): ?>
                        <div class="title big-title">
                            <h2><?php echo $Title ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if( $Description ): ?>
                        <div class="desc">
                            <?php echo $Description ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="category-filter">
                    <button class="filter-button active" data-category="all">All Jobs</button>
                    <?php
                    $jobs = get_sub_field('jobs');
                    $all_categories = array(); // Array to store all categories
                    if ($jobs) :
                        foreach ($jobs as $post) :
                            $post_categories = get_the_category($post->ID);
                            if ($post_categories) {
                                foreach ($post_categories as $category) {
                                    if (!in_array($category->name, $all_categories, true)) {
                                        $all_categories[] = $category->name;
                                        // Output the filter button for each category
                                        echo '<button class="filter-button" data-category="' . esc_attr($category->slug) . '">' . esc_html($category->name) . '</button>';
                                    }
                                }
                            }
                        endforeach;
                        wp_reset_postdata();
                    endif;
                    ?>
                </div>

            </div>
            <div class="offset-lg-1 col-lg-6 col-md-12 col-sm-12">
                
                <div class="job-box">
                    <div class="job-items">
                        <?php
                        $jobs = get_sub_field('jobs');
                        if ($jobs) :
                            foreach ($jobs as $post) :
                                setup_postdata($post);
                                ?>
                                <div class="product-single" data-category="<?php
                                    $post_categories = get_the_category();
                                    if ($post_categories) {
                                        $category_slugs = array_map(function ($cat) {
                                            return $cat->slug;
                                        }, $post_categories);
                                        echo esc_attr(implode(',', $category_slugs));
                                    }
                                    ?>">
                                    <div class="single-job">
                                        <div class="job-box-info">
                                            <div class="job-name">
                                                <h3><?php the_title(); ?></h3>
                                            </div>
                                            <div class="d-flex flex-wrap align-items-center">
                                                <div class="top-title box-element">
                                                    <p class="top-title-big"><?php the_field('job_type'); ?></p>
                                                </div>
                                                <div class="top-title">
                                                    <p class="top-title-big"><?php the_field('job_location'); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="job-btn">
                                            <button type="button" class="empty-custom-btn" onclick="location.href='<?php the_permalink() ?>';">
                                                Apply
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php
                            endforeach;
                            wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                </div>
                
            </div>
        </div>

    </div>
</section>
