<?php $Title = get_sub_field('text_and_pdf_title'); ?>
<?php $Description = get_sub_field('text_and_pdf_description'); ?>
<?php $Content = get_sub_field('text_and_pdf_content'); ?>

<section id="text-pdf">
    <div class="container">
        <div class="row flex-wrap align-items-start">
            <div class="col-lg-8 col-md-12 col-sm-12">
                <div class="content">
                    <?php if( $Content ): ?>
                        <?php echo $Content ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="offset-lg-1 col-lg-3 col-md-12 col-sm-12">
                <div class="pdf-box">
                    <?php if( $Title ): ?>
                        <div class="title">
                            <h5><?php echo $Title ?></h5>
                        </div>
                    <?php endif; ?>
                    <?php if( $Description ): ?>
                        <div class="description">
                            <?php echo $Description ?>
                        </div>
                    <?php endif; ?>
                    <div class="pdf-btn">
                        <?php
                        $file = get_sub_field('text_and_pdf_file');
                        if( $file ): ?>
                            <button  type="button" class="red-custom-btn" onclick=" window.open('<?php echo $file['url']; ?>','_blank')"> Download this form</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>