<?php

    // Student Subscriptions Block
    $className = 'year_month_subscribe';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $SmallTitle   = get_field('small_title');
    $BigTitle     = get_field('big_title');
    $Description  = get_field('description');


?>

<section class="<?php echo esc_attr($className); ?> container-width">
    <div class="wrapper">
        <div class="holder">
            
            <div class="year-month-box">
                
                <div class="col-lg-3 col-md-12 col-sm-12">

                    <div class="text">
                        <?php if ( $SmallTitle ) : ?>
                            <div class="small-title">
                                <p class="category-article"><?php echo $SmallTitle; ?></p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ( $BigTitle ) : ?>
                            <div class="big-title">
                                <h1><?php echo $BigTitle; ?></h1>
                            </div>
                        <?php endif; ?>
                    
                        <?php if ( $Description ) : ?>
                            <div class="description">
                                <?php echo $Description; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="col-lg-9 col-md-12 col-sm-12 tab-row">

                        <!-- Year -->
                        <div class="year-content single-box">
                            <div class="year-month-single-box">
                                <div class="content">
                                    <div class="top-title">
                                        <p class="category-article"><?php the_field('year_small_title'); ?></p>
                                    </div>
                                    <div class="price">
                                        <p><?php the_field('year_price'); ?> <span class="category-article">/ <?php the_field('year_price_period'); ?></span></p>
                                    </div>
                                    <div class="description">
                                        <?php the_field('year_description'); ?>
                                    </div>
                                    <div class="btn">
                                        <?php
                                            $link = get_field('year_btn_url');
                                                if( $link ):
                                                    $link_url = $link['url'];
                                                    $link_title = $link['title'];
                                            ?>
                                            <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                                <?php echo esc_html( $link_title ); ?>
                                                <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="features">
                                    <p class="category-article">features</p>
                                    <?php if( have_rows('year_features') ): ?> 
                                        <?php while( have_rows('year_features') ) : the_row(); ?>

                                            <div class="single-feature">
                                                <div class="icon">
                                                    <?php the_sub_field('year_feature_icon'); ?>
                                                </div>
                                                <div class="description">
                                                    <?php the_sub_field('year_features_description'); ?>
                                                </div>
                                            </div>

                                        <?php endwhile; ?>
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>

                        <!-- Custom -->
                        <div class="month-content single-box">
                            <div class="year-month-single-box">
                                <div class="content">
                                    <div class="top-title">
                                        <p class="category-article"><?php the_field('custom_small_title'); ?></p>
                                    </div>
                                    <div class="price">
                                        <p><?php the_field('custom_price'); ?> <span class="category-article">/ <?php the_field('custom_price_period'); ?></span></p>
                                    </div>
                                    <div class="description">
                                        <?php the_field('custom_description'); ?>
                                    </div>
                                    <div class="btn">
                                        <?php
                                            $link = get_field('custom_btn_url');
                                                if( $link ):
                                                    $link_url = $link['url'];
                                                    $link_title = $link['title'];
                                            ?>
                                            <button type="button" class="btn-white-arrow category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                                <?php echo esc_html( $link_title ); ?>
                                                <span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow.svg') ?>" alt=""></span>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="features">
                                    <p class="category-article">features</p>
                                    <?php if( have_rows('custom_features') ): ?> 
                                        <?php while( have_rows('custom_features') ) : the_row(); ?>

                                            <div class="single-feature">
                                                <div class="icon">
                                                    <?php the_sub_field('custom_feature_icon'); ?>
                                                </div>
                                                <div class="description">
                                                    <?php the_sub_field('custom_features_description'); ?>
                                                </div>
                                            </div>

                                        <?php endwhile; ?>
                                    <?php endif;?>
                                </div>
                            </div>
                        </div>
                        
                </div>
                
            </div>

        </div>
    </div>
</section>