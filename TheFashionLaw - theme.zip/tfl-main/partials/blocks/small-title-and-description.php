<?php

    // Small Title Descrioption Block
    $className = 'small_title_description';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $SmallTitle   = get_field('small_title');
    $BigTitle     = get_field('big_title');
    $Description  = get_field('description');


?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">

            <?php if ( $SmallTitle ) : ?>
                <div class="small-title">
                    <p class="category-article"><?php echo $SmallTitle; ?></p>
                </div>
            <?php endif; ?>
            
            <?php if ( $BigTitle ) : ?>
                <div class="big-title">
                    <h1><?php echo $BigTitle; ?></h1>
                </div>
            <?php endif; ?>
        
            <?php if ( $Description ) : ?>
                <div class="description font-19">
                    <?php echo $Description; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>