<?php $MapUrl = get_sub_field('map_url'); ?>

<section id="map">
    <div class="container-fluid p-0">
        <?php if( $MapUrl ): ?>
            <div class="map-box" style="overflow:hidden;">
            <iframe style="position:relative; top:-60px; border:none; margin-bottom: -65px;" 
                src="<?php echo $MapUrl ?>" 
                width="100%" height="680"></iframe>
            </div>
        <?php endif; ?>
    </div>
</section>