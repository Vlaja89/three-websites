<!-- Custom Cursor -->
<div class="custom-cursor"></div>
<!-- End Custom Cursor -->

<div id="portfolio">

    <div class="container">

        <div class="portfolio-box row flex-wrap align-items-start justify-content-center">
            <?php
                $portfolio = get_sub_field('portfolio');
                if( $portfolio ): ?>
                    <?php foreach( $portfolio as $post ): 

                        // Setup this post for WP functions (variable must be named $post).
                        setup_postdata($post); ?>
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="single-portfolio-box">
                                <div class="portfolio-img portfolio-cursor">
                                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="portfolio-content">
                                    <div class="portfolio-desc">
                                        <div class="portfolio-info d-flex align-items-center">
                                            <div class="portfolio-service box-element">
                                                <p><?php the_field('portfolio_service'); ?></p>
                                            </div>
                                            <div class="date">
                                                <p><?php echo get_the_date(); ?></p>
                                            </div>
                                        </div>
                                        <div class="portfolio-name">
                                            <h5><?php the_title(); ?></h5>
                                        </div>
                                    </div>
                                    <div class="portfolio-link custom-link">
                                        <a href="<?php the_permalink() ?>">
                                            <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-top-arrow.svg') ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>
                <?php 
                // Reset the global post object so that the rest of the page works correctly.
                wp_reset_postdata(); ?>
            <?php endif; ?>
        </div>

        <div class="portfolio-btn">
            <?php if( get_sub_field('portfolio_btn') ): ?>
            <!-- Button -->
                <?php 
                    $link = get_sub_field('portfolio_btn');
                    if( $link ): 
                        $link_url = $link['url'];
                        $link_title = $link['title'];
                        ?>
                        <div class="btn-box test-center">
                            <button type="button" class="dark-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                <?php echo esc_html( $link_title ); ?>
                            </button>
                            <img src="<?php echo get_theme_file_uri('./dist/img/red-circle-white-arrow-top.svg') ?>" alt="">
                        </div>
                    <?php endif; ?>
                <!-- End Button -->
            <?php endif; ?>
        </div>
        
    </div>

</div>