<!DOCTYPE html>
<html>

    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no" />
        <meta charset="UTF-8">
        <title><?php wp_title(''); ?></title>
        <?php wp_head(); ?>
    </head>

<body <?php body_class(); ?>>
<div class="page-holder">
        <?php
        $ptype = get_post_type();
        if (is_home() || is_front_page()) {
            $topClass = 'top-menu';
        } else {
            $topClass = 'top-menu inner-menu';
//                $secLogo = get_field('secondary_logo', 'option');
        }
        ?>
        <div class="<?php echo $topClass; ?>">
            <div id="target" class="header-search-form">
                <p class="close-form">X</p>
                <?php get_search_form(); ?>
            </div>
            <div class="top-links">
                <div class="container">
                    <div class="top-links-box">
                        <?php if( have_rows('top_links', 'option') ): ?>
                            <?php $count = 1 ?>
                            <?php while( have_rows('top_links', 'option') ): the_row(); ?>
                                <div class="single-link" id="link-<?php echo $count; ?>">
                                    <p>
                                        <a href="<?php the_sub_field('top_links_link', 'option') ?>">
                                            <?php the_sub_field('top_links_title', 'option') ?>
                                        </a>
                                    </p>
                                </div>
                            <?php $count++; endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="main-header">
                <div class="container">
                    <div class="row">
                        <nav class="navbar navbar-expand-lg d-flex justify-content-between align-items-center w-100">
                            <div class="logo">
                                <?php the_custom_logo(); ?>
                            </div>
                            <div class="collapse navbar-collapse mobile-menu justify-content-end" id="navbarNavDropdown">
                                <div class="menu-links">
                                    <?php
                                        if (has_nav_menu('menu')) {
                                            wp_nav_menu(array(
                                                'theme_location' => 'menu',
                                                'menu_class' => 'navbar-nav justify-content-center justify-content-md-end align-items-center',
                                                'container' => 'ul'
                                            ));
                                        }
                                    ?>
                                    <div class="woo-cart">
                                        <?php display_cart_count_icon(); ?>
                                    </div>
                                    <div class="toggle">
                                        <div id="myInput">
                                            <?php get_search_form(); ?>
                                        </div>
                                        <img src="<?php echo get_theme_file_uri('./dist/img/search.svg') ?>" alt="" id="toggleButton">
                                    </div>

                                </div>
                            </div>

                            <div class="hamburger-menu mob-block">
                                <div class="woo-cart">
                                    <?php display_cart_count_icon(); ?>
                                </div>
                                <div id="menuToggle">
                                    <input type="checkbox" />
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <ul id="menu">
                                        <div class="test">
                                            
                                        <div class="container">
                                            <div class="custom-logo-hamb">
                                                <img src="<?php the_field('white_logo', 'option') ?>" alt="" class="img-fluid">
                                            </div>
                                            <div class="head-bg">
                                                <div class="top-mob-menu">
                                                    <?php
                                                        if (has_nav_menu('menu')) {
                                                            wp_nav_menu(array(
                                                                'theme_location' => 'menu',
                                                                'menu_class' => 'navbar-nav',
                                                                'container' => 'ul'
                                                            ));
                                                        }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="search-mob-box">
                                                <div class="search-mob">
                                                    <?php get_search_form(); ?>
                                                </div>
                                            </div>
                                        </div>
                                        </div>

                                    </ul>
                                </div>
                            </div>
                        </nav>
                        
                    </div>
                </div>
            </div>
        </div>
