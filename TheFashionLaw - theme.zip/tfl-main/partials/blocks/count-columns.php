<?php

    // Count Columns Block
    $className = 'count_columns';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $CountTitle  = get_field('count_title');
    $CountDescription  = get_field('count_descripiton');

?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">

            <div class="count-content">
                <?php if ( $CountTitle ) : ?>
                    <div class="count-title">
                        <h2 class="general"><?php echo $CountTitle; ?></h2>
                    </div>
                <?php endif; ?>

                <?php if ( $CountDescription ) : ?>
                    <div class="count-descitpion">
                        <?php echo $CountDescription; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if( get_field('count_rep') ): ?>
                <div class="count-box">
                    <?php if( have_rows('count_rep') ): ?> 
                        <?php while( have_rows('count_rep') ) : the_row(); ?>

                            <div class="single-count-box">
                                <div class="count-number">
                                    <p><?php echo get_row_index(); ?></p>
                                </div>
                                <div class="count-title">
                                    <p><?php the_sub_field('count_rep_title'); ?></p>
                                </div>
                                <div class="count-description">
                                    <?php the_sub_field('count_rep_descripiton'); ?>
                                </div>
                            </div>

                        <?php endwhile; ?>
                    <?php endif;?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>