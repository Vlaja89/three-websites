<?php get_header('home'); ?>

	<div class="container-width"> 	
		<div class="home-box">
			
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


				<div class="col-left">

					<!-- Last Added Post -->
					<div class="main-post">
						<?php $args = array(  
							'post_type' => 'post',
							'post_status' => 'publish',
							'posts_per_page' => 1, 
						);

						$loop = new WP_Query( $args ); 
						while ( $loop->have_posts() ) : $loop->the_post(); ?>
		
								<div class="main-post-box">
									<a href="<?php the_permalink() ?>" itle="<?php the_title(); ?>">
										<div class="image">
											<img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title();?>" class="img-fluid">
										</div>
									</a>
									<div class="main-bg-box">
										<div class="small-title">
											<p class="category-article">
												<?php include 'partials/parts/post-primary-category.php'; ?>
											</p>
											<div class="read-time">
												<p><span>|</span></p>
												<?php 
													$reading_time = estimate_reading_time($post_id);
													if ( $reading_time ) :
												?>
													<p><?php echo $reading_time; ?> min read</p>
												<?php endif; ?>
											</div>
										</div>
										<a href="<?php the_permalink() ?>" itle="<?php the_title(); ?>">
											<div class="big-title">
												<h1><?php the_title();?></h1>
											</div>
										</a>
										<!-- Display Co Authors -->
										<?php $coauthors = get_coauthors(); ?>
										<?php if (!empty($coauthors)) { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By

												<?php $author_count = count($coauthors);
												foreach ($coauthors as $index => $coauthor) {
													$author_url = get_author_posts_url($coauthor->ID);

													// Output author name with a link to their profile
													if ($author_url) {
														echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

														// Add a comma and space if there are more authors
														if ($index < $author_count - 1) {
															echo ', ';
														}
													}
												} ?>

												</p>
											</div> 
										<?php } else { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By Unknown Author</p>
											</div>
										<?php } ?>
										<!-- End Display Co Authors -->
									</div>
								</div>
								
						<?php endwhile; ?> 
						<?php wp_reset_postdata(); ?> 
					</div>
					<!-- End Last Added Post -->
					
					<!-- Block Content -->
					<?php the_content(); ?>
					<!-- End Block Content -->

					<!-- Category Tabs -->
					<?php $args = array(
						'hide_empty'=> 1,
						'orderby' => 'name',
						'order' => 'ASC'
					); ?>

					<div class="tabs-top mob-tab">
						<div class="blue-box-title">
							<p>Latest</p>
							<div class="d-991-none">
								<ul class="cat-tabs" role="tablist">
									<li class="active">
										<a href="#all" role="tab" class="category-article" data-toggle="tab">All</a>
									</li>
									<?php $categories = get_categories($args);
										foreach($categories as $category) { 
												$active_for_filter = get_field('active_for_filter', $category);
												if( $active_for_filter == true ) :
											?>
											<li>
												<a href="<?php echo site_url(); ?>/<?php echo $category->slug ?>/" class="category-article" role="tab" data-toggle="tab">    
													<?php echo $category->name; ?> 
												</a>
											</li>
									<?php endif; } ?>
								</ul>
							</div>
							<div class="d-991-block mob-nav">
								<div class="showBtn">
									<h6 class="category-article">All</h6>
								</div>
								<div class="hideme">
									<ul class="cat-tabs" role="tablist">
										<li class="active">
											<a href="#all" role="tab" class="category-article" data-toggle="tab">All</a>
										</li>
										<?php $categories = get_categories($args);
											foreach($categories as $category) { 
												$active_for_filter = get_field('active_for_filter', $category);
												if( $active_for_filter == true ) :
												?>
												<li>
													<a href="<?php echo site_url(); ?>/<?php echo $category->slug ?>/" class="category-article" role="tab" data-toggle="tab">    
														<?php echo $category->name; ?> 
													</a>
												</li>
										<?php endif; } ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-- End Category Tabs -->

					<div class="tabs-content">

							<!-- All Posts -->
							<div class="tab-pane" id="all">
								<?php $the_query = new WP_Query(array(
									'post_type' => 'post',
									'posts_per_page' => 15,
									'offset' => 1,
									'tax_query' => array(
										'relation' => 'AND',
										array(
											'taxonomy' => 'category',
											'field' => 'slug',
											'terms' => 'featured',
											'operator' => 'NOT IN',
										),
									),
									'post__not_in' => get_all_page_ids(), // Excludes pages from the query
								));

								while ( $the_query->have_posts() ) : 
								$the_query->the_post(); 
									$post_id = get_the_ID();
								?>

									<div class="single-blog-post col-lg-4 col-md-6 col-sm-12">
											<div class="small-title">
												<p class="category-article">
													<?php include 'partials/parts/post-primary-category.php'; ?>
												</p>
												<div class="read-time">
													<p><span>|</span></p>
													<?php 
														$reading_time = estimate_reading_time($post_id);
														if ( $reading_time ) :
													?>
														<p><?php echo $reading_time; ?> min read</p>
													<?php endif; ?>
												</div>
											</div>
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
												<div class="image">
													<!-- Thumbnail image -->
													<?php if ( has_post_thumbnail() ) { ?>
														<img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title();?>" class="img-fluid">
													<? } else { ?>
														<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
													<?php } ?> 
													<!-- End Thumbnail image -->     
												</div>
											</a>
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
												<div class="big-title main-post">
													<h2><?php the_title();?></h2>
												</div>
											</a>
											<!-- Display Co Authors -->
											<?php $coauthors = get_coauthors(); ?>
											<?php if (!empty($coauthors)) { ?>
												<div class="date-author">
													<p><?php echo get_the_date(); ?> - By

													<?php $author_count = count($coauthors);
													foreach ($coauthors as $index => $coauthor) {
														$author_url = get_author_posts_url($coauthor->ID);

														// Output author name with a link to their profile
														if ($author_url) {
															echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

															// Add a comma and space if there are more authors
															if ($index < $author_count - 1) {
																echo ', ';
															}
														}
													} ?>

													</p>
												</div> 
											<?php } else { ?>
												<div class="date-author">
													<p><?php echo get_the_date(); ?> - By Unknown Author</p>
												</div>
											<?php } ?>
										<!-- End Display Co Authors -->
									</div>
									
								<?php endwhile; ?>
							</div>
							<!-- End All Posts -->

					</div>
					
				</div>

				<div class="col-right">
							
					<!-- In the News -->
					<div class="news-side-box">
						<div class="blue-box-title">
							<p>In the News</p>
						</div>
						<?php
							$postNews = new WP_Query(array(
								'post_type' 		=> 'post',
								'posts_per_page' 	=> 4,
								'offset' 			=> 1,
								'tax_query' 		=> array(
								'relation' 			=> 'AND',
								array(
									'taxonomy' 		=> 'category',
									'field' 		=> 'slug',
									'terms' 		=> 'featured',
									'operator' 		=> 'NOT IN',
								),
							),
							'post__not_in' => get_all_page_ids(), // Excludes pages from the query
							));
						?>
							
						<?php if ($postNews->have_posts()) : 
							while ($postNews->have_posts()) : 
							$postNews->the_post(); ?>

									<div class="single-news-post">
										<div class="small-title">
											<p class="category-article">
												<?php include 'partials/parts/post-primary-category.php'; ?>
											</p>
											<div class="read-time">
												<p><span>|</span></p>
												<?php 
													$reading_time = estimate_reading_time($post_id);
													if ( $reading_time ) :
												?>
													<p><?php echo $reading_time; ?> min read</p>
												<?php endif; ?>
											</div>
										</div>
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
											<div class="big-title main-post">
												<h2><?php the_title();?></h2>
											</div>
										</a>
										<!-- Display Co Authors -->
										<?php $coauthors = get_coauthors(); ?>
											<?php if (!empty($coauthors)) { ?>
												<div class="date-author">
													<p><?php echo get_the_date(); ?> - By

													<?php $author_count = count($coauthors);
													foreach ($coauthors as $index => $coauthor) {
														$author_url = get_author_posts_url($coauthor->ID);

														// Output author name with a link to their profile
														if ($author_url) {
															echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

															// Add a comma and space if there are more authors
															if ($index < $author_count - 1) {
																echo ', ';
															}
														}
													} ?>

													</p>
												</div> 
											<?php } else { ?>
												<div class="date-author">
													<p><?php echo get_the_date(); ?> - By Unknown Author</p>
												</div>
											<?php } ?>
										<!-- End Display Co Authors -->
									</div>
							
							<?php endwhile; ?>
							<?php wp_reset_postdata(); ?>
						<?php endif; ?>
					</div>
					<!-- End In the News -->
					
					<!-- Popular -->
					<div class="popular-side-box">
						<div class="blue-box-title">
							<p>Popular</p>
						</div>

						<?php
							$postPopulars = get_field('popular_posts', 'option');
							if( $postPopulars ) :
								$count = 1;
						?>
							
							<?php
								foreach( $postPopulars as $postPopular ) :
									$title 		= get_the_title( $postPopular->ID );
									$permalink 	= get_the_permalink( $postPopular->ID );
							?>

								<a href="<?php echo $permalink; ?>" rel="bookmark" title="<?php echo $title; ?>">
									<div class="single-popular-post">
										<div class="post-number">
											<p><?php echo str_pad(strval($count), 2, '0', STR_PAD_LEFT); ?></p>
										</div>
										<div class="big-title main-post">
											<h2><?php echo $title; ?></h2>
										</div>
									</div>
								</a>
								
							<?php $count++; endforeach; ?>
						<?php endif; ?>
					</div>
					<!-- End Popular -->

					<div class="button-box">
						<div class="button-box-title main-post">
							<h1><?php the_field('sidebar_box_title') ?></h1>
						</div>
						<div class="box-btn">
							<?php
								$link = get_field('sidebar_box_link');
									if( $link ):
										$link_url = $link['url'];
										$link_title = $link['title'];
								?>
								<button type="button" class="color-btn category-article" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
									<?php echo esc_html( $link_title ); ?>
									<span><img src="<?php echo get_theme_file_uri('./assets/images/white-arrow-tiny.svg') ?>" alt=""></span>
								</button>
							<?php endif; ?>
						</div>
					</div>
				
				</div>

			<?php endwhile; endif; ?>
		
		</div>

		<!-- Updated Post -->
		<div class="updated-posts">
			<div class="updated-title blue-box-title">
				<p>Case updates</p>
			</div>

			<div class="updated-slider">
					<?php 
						$updated_query = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' => 8
						)); 
					?>
					<?php while ( $updated_query->have_posts() ) : 
					$updated_query->the_post(); ?>

					<div class="updated-blog-post">
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
							<div class="big-title">
								<h3><?php the_title();?></h3>
							</div>
						</a>
					</div>
				<?php endwhile; ?>
			</div>
		</div>
		<!-- End Updated Post -->

	</div>

<?php get_footer('home'); ?>