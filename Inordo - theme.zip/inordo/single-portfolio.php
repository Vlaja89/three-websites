<?php get_header(); ?>

<div id="wrapp">

    <div class="container">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

                <div class="single-portfolio-content">

                    <div class="top-info">
                        <div class="title big-title">
                            <h2><?php the_title(); ?></h2>
                        </div>

                        <div class="d-flex flex-wrap aligm-items-start">
                            <div class="top-title">
                                <p>Service</p>
                                <h5><?php the_field('portfolio_service'); ?></h5>
                            </div>
                            <div class="top-title">
                                <p>INDUSTRY</p>
                                <h5><?php the_field('portfolio_industry'); ?></h5>
                            </div>
                            <div class="top-title">
                                <p>CLIENT</p>
                                <h5><?php the_field('portfolio_client'); ?></h5>
                            </div>
                            <div class="top-title">
                                <p>YEAR</p>
                                <h5><?php echo get_the_date('Y'); ?></h5>
                            </div>
                        </div>
                    </div>

                    <div class="single-portfolio-img">
                        <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title();?>" class="img-fluid">
                    </div>

                    <div class="main-excerpt small-width">
                        <p class="grey-title">about project</p>
                        <h5><?php echo get_the_excerpt() ?></h5>
                    </div>

                    <div class="flex-content">
                        <?php if( have_rows('portfolio_content') ):
                            while ( have_rows('portfolio_content') ) : the_row(); ?>

                                <?php $Content = get_sub_field('portfolio_desc'); ?>
                                
                                <?php $Image = get_sub_field('portfolio_img'); ?>
                                
                                <?php $ImageLeft = get_sub_field('portfolio_img_left'); ?>
                                <?php $ImageRIght = get_sub_field('portfolio_img_right'); ?>

                                        <?php if( $Content ): ?>
                                            <div class="single-content small-width">
                                                <?php echo $Content; ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if( $Image ): ?>
                                            <div class="one-img">
                                                <img src="<?php echo $Image ?>" alt="" class="img-fluid">
                                            </div>
                                        <?php endif; ?>

                                        <?php if( $ImageLeft ): ?>
                                            <div class="two-images">
                                                <div class="img-left ">
                                                    <img src="<?php echo $ImageLeft ?>" alt="" class="img-fluid">
                                                </div>
                                                <div class="img-right">
                                                    <img src="<?php echo $ImageRIght ?>" alt="" class="img-fluid">
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                <?php endwhile; ?>
                            <?php else : ?>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endwhile; ?>
        <?php endif; ?>

        <div id="portfolio" class="related-works single-portfolio-content">

            <div class="main-title">
                <div class="title big-title">
                    <h3>Other Projects</h3>
                </div>
                
                <div class="post-btn">
                    <div class="btn-box">
                        <button type="button" class="dark-custom-btn" onclick="location.href='/works';">
                            View all works
                        </button>
                        <img src="<?php echo get_theme_file_uri('./dist/img/red-circle-white-arrow-top.svg') ?>" alt="">
                    </div>
                </div>
            </div>

            <div class="row flex-wrap align-items-start">
                <?php
                    //query arguments
                    $args = array(
                        'post_type' => 'portfolio',
                        'post_status' => 'publish',
                        'posts_per_page' => 2,
                        'orderby' => 'rand',
                        'post__not_in' => array ($post->ID),
                    );

                    //the query
                    $relatedPosts = new WP_Query( $args );

                    //loop through query
                    if($relatedPosts->have_posts()){
                        while($relatedPosts->have_posts()){ 
                            $relatedPosts->the_post();
                    ?>
                        
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="single-portfolio-box">
                                <div class="portfolio-img">
                                    <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                    </a>
                                </div>
                                <div class="portfolio-content">
                                    <div class="portfolio-desc">
                                        <div class="portfolio-info d-flex align-items-center">
                                            <div class="portfolio-service box-element">
                                                <p><?php the_field('portfolio_service'); ?></p>
                                            </div>
                                            <div class="date">
                                                <p><?php echo get_the_date(); ?></p>
                                            </div>
                                        </div>
                                        <div class="portfolio-name">
                                            <h5><?php the_title(); ?></h5>
                                        </div>
                                    </div>
                                    <div class="portfolio-link custom-link">
                                        <a href="<?php the_permalink() ?>">
                                            <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-top-arrow.svg') ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>

                    <?php
                        }
                    } 

                    //restore original post data
                    wp_reset_postdata();
                ?>

            </div>
        </div>

    </div>
    
</div>
     
<?php get_footer(); ?>