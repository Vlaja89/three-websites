<section id="blog-posts">
    <div class="container">
        <div class="top-filters">
            <div class="filter-desc">
                <p>Select Category:</p>
            </div>
            <div class="category-filter">
                <button class="filter-button active" data-category="all">All Posts</button>
                <?php
                $all_categories = array(); // Array to store all categories

                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => -1,
                    'order' => 'DESC',
                    'post_status' => 'publish'
                );

                $query = new WP_Query($args);

                if ($query->have_posts()) :
                    while ($query->have_posts()) :
                        $query->the_post();
                        $post_categories = get_the_category();
                        if ($post_categories) {
                            foreach ($post_categories as $category) {
                                if (!in_array($category->name, $all_categories, true)) {
                                    $all_categories[] = $category->name;
                                    // Output the filter button for each category
                                    echo '<button class="filter-button" data-category="' . esc_attr($category->slug) . '">' . esc_html($category->name) . '</button>';
                                }
                            }
                        }
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
        <div class="posts-box">
            <div class="post-items element-list">
                <?php
                $args = array(
                    'post_type' => 'post',
                    'posts_per_page' => -1,
                    'order' => 'DESC',
                    'post_status' => 'publish'
                );

                $query = new WP_Query($args);

                if ($query->have_posts()) :
                    while ($query->have_posts()) :
                        $query->the_post();
                        ?>
                        <div class="product-single" data-category="<?php
                            $post_categories = get_the_category();
                            if ($post_categories) {
                                $category_slugs = array_map(function ($cat) {
                                    return $cat->slug;
                                }, $post_categories);
                                echo esc_attr(implode(',', $category_slugs));
                            }
                            ?>">
                            <div class="single-post">
                                <div class="post-info">
                                    <div class="d-flex align-items-center">
                                        <div class="category box-element">
                                            <?php
                                            $categories = get_the_category(); // Get all categories for the current post
                                            if ($categories) {
                                                $primary_category = $categories[0]; // Get the first category (primary category)
                                                echo '<p><a href="' . get_category_link($primary_category->cat_ID) . '">' . $primary_category->cat_name . '</a></p>';
                                            }
                                            ?>
                                        </div>
                                        <div class="date">
                                            <p><?php echo get_the_date(); ?></p>
                                        </div>
                                    </div>
                                    <div class="post-name">
                                        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                            <h3><?php the_title(); ?></h3>
                                        </a>
                                    </div>
                                </div>
                                <div class="arrow-link">
                                    <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                        <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-arrow.svg') ?>" alt="">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
            <div class="btn-box">
                <button class="empty-custom-btn show-more">Load More</button>
                <img src="<?php echo get_theme_file_uri('./dist/img/black-three-dots.svg') ?>" alt="" class="show-more">
            </div>
        </div>
    </div>
</section>
