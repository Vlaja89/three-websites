<?php $Title = get_sub_field('image_content_title'); ?>
<?php $Content = get_sub_field('image_content_description'); ?>
<?php $Name = get_sub_field('image_content_name'); ?>
<?php $Position = get_sub_field('image_content_position'); ?>

<div id="image-content">
    <div class="container">

        <div class="row flex-wrap align-items-start justify-content-center">

            <?php if( get_sub_field('image_content_imgs') ): ?>
                <div class="col-lg-6 col-md-12 col-sm-12 section-order-1">
                    <div class="images-box">
                        <?php if( have_rows('image_content_imgs') ): ?>
                            <?php $count = 1; ?>
                            <?php while( have_rows('image_content_imgs') ): the_row(); ?>
                                
                                <div class="image" id="img-circle-<?php echo $count; ?>">
                                    <img src="<?php the_sub_field('image_content_img') ?>" alt="" class="img-fluid">
                                </div>
                            
                            <?php $count++; endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
                <div class="col-lg-6 col-md-12 col-sm-12 section-order-2">
                    <div class="content-box">
                        <?php if( $Title ): ?>
                            <div class="title big-title">
                                <h3><?php echo $Title ?></h3>
                            </div>
                        <?php endif; ?>
                        <?php if( $Content ): ?>
                            <div class="desc">
                                <?php echo $Content ?>
                            </div>
                        <?php endif; ?>
                        <?php if( $Name ): ?>
                            <div class="name">
                                <p><?php echo $Name ?></p>
                            </div>
                        <?php endif; ?>
                        <?php if( $Position ): ?>
                            <div class="position">
                                <p><?php echo $Position ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

        </div>
        
    </div>
</div>
