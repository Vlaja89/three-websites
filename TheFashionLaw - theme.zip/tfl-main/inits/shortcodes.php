<?php 
/**
 * Shortcodes
 *
 * @package starter_wp_theme
 */

// add shortcode [zeleno] for texteditor
// function zeleno_shortcode( $atts, $content = null ) {
// 	return '<i class="zeleno-color">' . $content . '</i>';
//   	return $content;
// }
// add_shortcode( 'zeleno', 'zeleno_shortcode' );