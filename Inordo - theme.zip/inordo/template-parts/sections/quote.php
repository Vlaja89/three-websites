<?php $Title = get_sub_field('quote_title'); ?>
<?php $Name = get_sub_field('quote_name'); ?>

<div id="quote">

    <div class="container">
        <div class="quote-content">
            <div class="quote-icon">
                <img src="<?php echo get_theme_file_uri('./dist/img/quote.svg') ?>" alt="">
            </div>
            <?php if( $Title ): ?>
                <div class="title">
                    <h2><?php echo $Title ?></h2>
                </div>
            <?php endif; ?>
            
            <?php if( $Name ): ?>
                <div class="desc box-element">
                    <p><?php echo $Name ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
</div>