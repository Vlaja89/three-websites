<?php 
    $image      = get_field('image');
    $subtitle   = get_field('subtitle');
    $title      = get_field('title');
    $text       = get_field('text');
    // Neka bude ovako za sada, verovatno ce se promeniti u relationship
?>

<section class="featured-post">
    <div class="wrapper">
        <div class="holder">
            <div class="image">
                <?php if( !empty($image) ): ?>
                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
                <?php endif; ?>
            </div>
            <div class="text">
                <?php if ($subtitle) : ?>
                    <h4><?php echo $subtitle; ?></h4>
                <?php endif; ?>

                <?php if ($title) : ?>
                    <h2><?php echo $title; ?></h2>
                <?php endif; ?>

                <?php if ($text) : ?>
                    <p><?php echo $text; ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section><!-- Featured Post -->

<section class="related-posts">
    <div class="wrapper">
        <div class="holder">
            <ul class="posts-list">
                <li>
                    <div class="top">
                        <div class="category">
                            <?php 
                                $categories = get_the_category();
                                if ( ! empty( $categories ) ) {
                                    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '">' . esc_html( $categories[0]->name ) . '</a>';
                                }
                            ?>
                            | time read
                        </div>
                        <img src="http://localhost:8888/wordpress/wp-content/uploads/2020/10/featured-post-1.jpg" alt="">
                    </div>
                    <article>
                        <h4>Burberry Reports $1.6 Billion in H1 Revenue, Reveals Accessories-Centric Plan</h4>
                        <div class="meta">
                            <?php get_the_date( 'F j, Y' ) ?> - By <?php the_author(); ?>
                        </div>
                    </article>
                </li>
            </ul>
        </div>
    </div>
</section><!-- Related Posts -->