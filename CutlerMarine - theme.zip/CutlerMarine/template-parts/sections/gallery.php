<?php $Title = get_sub_field('gallery_tilte'); ?>
<?php $Content = get_sub_field('gallery_content'); ?>

<section id="gallery">

    <?php if( $Title ): ?>
        <div class="container">
            <div class="title text-center">
                <h3><?php echo $Title ?></h3>
            </div>
        </div>
    <?php endif; ?>

    <?php if( $Content ): ?>
        <div class="container">
            <div class="description text-center">
                <?php echo $Content ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="container-fluid p-0">
        <div class="gallery-content">
            <div class="partners-slider">
                <?php $images = get_sub_field('gallery_imgs'); ?>
                <?php if( $images ): ?>
                    <?php foreach( $images as $image ): ?>
                        <div class="img-box">
                            <img src="<?php echo $image['sizes']['large']; ?>" alt="" class="img-fluid"/>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

</section>

