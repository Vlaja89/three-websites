<?php $Title = get_sub_field('text_image_title'); ?>
<?php $Content = get_sub_field('text_image_description'); ?>
<?php $Image = get_sub_field('text_image_img'); ?>

<section id="image-text">
    <div class="container">
        <div class="row flex-wrap align-items-center">
            <div class="col-lg-6 col-md-12 col-sm-12">
                <?php if( $Title ): ?>
                    <div class="title">
                        <h3><?php echo $Title ?></h3>
                    </div>
                <?php endif; ?>
                <?php if( $Content ): ?>
                    <div class="description">
                        <?php echo $Content ?>
                    </div>
                <?php endif; ?>
                <?php if( get_sub_field('text_image_btn') ): ?>
                <!-- Button -->
                    <?php 
                        $link = get_sub_field('text_image_btn');
                        if( $link ): 
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                            ?>
                            <a class="custom-link" href="<?php echo esc_url( $link_url ); ?>"><?php echo esc_html( $link_title ); ?></a>
                        <?php endif; ?>
                    <!-- End Button -->
                <?php endif; ?>
            </div>
            <?php if( $Image ): ?>
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="image">
                        <img src="<?php echo $Image ?>" alt="" class="img-fluid"/>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>