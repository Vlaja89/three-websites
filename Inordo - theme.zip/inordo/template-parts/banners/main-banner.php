<?php $Title = get_sub_field('banner_title'); ?>
<?php $Desc = get_sub_field('banner_description'); ?>
<?php $ScrollDesc = get_sub_field('scroll_description'); ?>


<div id="main-banner">

    <div class="container">

        <div class="row flex wrap align-items-start">
            <div class="col-lg-2 col-md-12 col-sm-12 section-order-1">
                <div class="banner-service">
                    <?php if( have_rows('banner_services') ): ?>
                        <?php while( have_rows('banner_services') ): the_row(); ?>

                            <div class="single-service box-element">
                                <p title="This is a trick, we knew you’ll be clicking this!" class="service-bubble"><?php the_sub_field('single_service'); ?></p>
                            </div>
                        
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-8 col-md-12 col-sm-12 section-order-2">
                <div class="banner-content">
                    <?php if( $Title ): ?>
                        <div class="title">
                            <h1>
                                <?php echo $Title ?>
                                <img src="<?php echo get_theme_file_uri('./dist/img/banner-arrow.svg') ?>" alt="" class="img-fluid">
                            </h1>
                        </div>
                    <?php endif; ?>
                    
                    <?php if( $Desc ): ?>
                        <div class="desc">
                            <?php echo $Desc ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        
        <div class="scroll-down">
            <?php if( $ScrollDesc ): ?>
                <div class="scroll-desc">
                    <p><?php echo $ScrollDesc ?></p>
                </div>
            <?php endif; ?>
            <div class="arrow bounce">
                <img src="<?php echo get_theme_file_uri('./dist/img/tiny-black-arrow.svg') ?>" alt="">
            </div>
        </div>
    </div>
    
</div>