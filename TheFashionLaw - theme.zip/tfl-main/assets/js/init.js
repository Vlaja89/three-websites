(function ($) {
    $(document).ready(function () {

        // Display menu after page load
        $(function() {
            setTimeout(function() { 
                $("#menu").show(); 
            }, 500)
        });

        if ($(window).scrollTop() > 50) {
          $("header").addClass("current");
        } else {
          $("header").removeClass("current");
        }

        if( $('.pdfemb-viewer').length ) {
          $('body').addClass('single-case-pdf');
        }

        // Sticky Header
        $(function () {
          $(window).on("scroll", function () {
              if ($(window).scrollTop() > 50) {
                  $("header").addClass("current");
              } else {
                  $("header").removeClass("current");
              }
          });
        });

        // Hide and Show Search Input in Header
        $('.toggle').click(function() {
            $('#target').toggle('slow');
        });
        $(".close-form").click(function(){
            $('#target').toggle('slow');
        });

        // Add class on Toggle click
        $("#menuToggle input").click(function(){
            $('#menuToggle').toggleClass("fixed-toggle");
        });

        // Year and Month Tabs
        $('.tab').on('click', function(e) {
            e.preventDefault();
            $('a.tab').removeClass("active");
            $(this).addClass("active");
            var sel = this.getAttribute('data-toggle-target');
            $('.tab-content').removeClass('active').filter(sel).addClass('active');
        });

        // FAQ Toggle and Archive category list Toggle
        $('.showBtn').click(function() {
            //$('.hideme').hide();  
            if ($(this).hasClass('active')) {    
                $(this).removeClass('active');
                $('.hideme').slideUp();
            } else {
                $('.hideme').slideUp();
                $('.showBtn').removeClass('active');
                $(this).addClass('active');
                $(this).next().filter('.hideme').slideDown();
            }
        });

        // Remove and add class on H2 tag on Single post tempalte
        $('.single-post-content h2').removeClass("general");
        $('.single-post-content h2').addClass("blog-entries");

        // Categories Tabs On Homepage
        $(function() {
            $('.cat-tabs a').click(function(e) {

              e.preventDefault();

              var curr = $(this),
                currUrl = curr.attr('href'),
                currID = curr.data('id');

              $.ajax({
                type: 'POST',
                url: currUrl,
                data: {
                },
                beforeSend: function () {
                  
                },
                error: function () {
                 
                },
                success: function (response) {
                  var htmlResponse = $(response).find('.tab-pane').html();
                  
                  $('.tabs-content .tab-pane').children().remove();
                  $('.tabs-content .tab-pane').append(htmlResponse);
                  $('.tabs-content .tab-pane .custom-pagination').remove();

                  $('.tags-trigger').attr('data-category', currID).attr('data-tag', '');
                  $('.single-tag input').prop('checked', false);
                },
                complete: function () {
                  curr.parents('.cat-tabs').find('li').removeClass('active');
                  curr.parent().addClass('active');
                },

              });

            });

            $('.tags-trigger').click(function(e) {
            
              e.preventDefault();

              var selectedTags = [];

              $(".single-tag input:checked").each(function() {
                var currID = $(this).attr('data-tagid');
                selectedTags.push(currID);
              });

              $(this).attr("data-tag", selectedTags.join());

              var curr = $(this),
                currTag = curr.attr('data-tag'),
                currCat = curr.attr('data-category');

              $.ajax({
                type: 'POST',
                url: ajaxurl,
                // dataType: "html",
                data: {
                  action : 'category_tags_filter',
                  'currTag' : currTag,
                  'currCat' : currCat,
                }, 
                success: function(response){
                  // console.log(response);
                  $('.tab-pane').empty();
                  $('.tab-pane').append(response);
                }
              });

            });

            $('.tags-reset').click(function(e) {
            
              e.preventDefault();

              $('.cat-tabs a[href="#all"]').click();
              $('#toggleButton').click();

            });

        });

         // Updated Post Slider Homepage
        $('.updated-slider').slick({
            dots: false,
            arrows: true,
            infinite: true,
            autoplay: false,
            autoplaySpeed: 3000,
            speed: 1200,
            pauseOnHover: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [
              {
                breakpoint: 1199,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                  dots: false,
                },
              },
              {
                breakpoint: 991,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1,
                  dots: false,
                },
              },
              {
                breakpoint: 767,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  dots: false,
                },
              }
            ],
        });

        // Post Tags Toggle Button
        $('#toggleButton').click(function() {
            $('#content').toggle();
            $(this).toggleClass('active');
            // if ($('#content').is(':visible')) {
            //   $('#toggleIcon').attr('src', '/wp-content/uploads/2023/06/white-minus.png');
            // } else {
            //   $('#toggleIcon').attr('src', '/wp-content/uploads/2023/06/white-plus.png');
            // }
        });

        // Add cursor on input field after open toggle form
        $(".search-icon .toggle").click(function() {
          $('#search').focus();
        });

        if ($('ev-engagement[group-name="myAccount"]').length > 0) {
          $('.default-post-style').addClass('evolok-wrapper');
        }

    });
}(jQuery));
