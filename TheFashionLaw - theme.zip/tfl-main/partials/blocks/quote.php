<?php

    // Quote Block
    $className = 'quote';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $Quote  = get_field('quote');

?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">

            <?php if ( $Quote ) : ?>
                <div class="quote-box">
                    <?php echo $Quote; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>