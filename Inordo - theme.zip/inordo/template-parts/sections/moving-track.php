<?php $Title = get_sub_field('track_title'); ?>

<div id="moving-track">

    <div class="container-fluid p-0">

        <div class="track-content">
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
            <p>
                <?php echo $Title ?>
                <img src="<?php echo get_theme_file_uri('./dist/img/light.svg') ?>" alt="">
            </p>
        </div>
        
    </div>
    
</div>