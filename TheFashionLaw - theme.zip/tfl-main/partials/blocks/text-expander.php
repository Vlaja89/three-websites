<?php

    // Text Expander Block
    $className = 'text_expander';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $block_width = get_field('block_width');
    $title      = get_field('title');
    $text       = get_field('text');
    $image      = get_field('image');

    // Subscribe FAQ, sredicu ja posle ove brojeve da idu od nule do 9 itd. Ovo cemo naknadno da ubacimo za width blokova
?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper <?php echo $block_width; ?>">
        <div class="holder">
            <div class="text">

                <?php if ($title) : ?>
                    <h4><?php echo $title; ?></h4>
                <?php endif; ?>

                <?php if ($text) : ?>
                    <p><?php echo $text; ?></p>
                <?php endif; ?>
                
            </div>

            <?php if( get_field('expander_rows') ): ?>
                <div class="expander-holder">
                    <?php if( have_rows('expander_rows') ): ?> 
                        <ul>
                            <?php 
                                while( have_rows('expander_rows') ) : the_row(); 
                                    $expanderTitle  = get_sub_field('expander_title');
                                    $expanderText   = get_sub_field('expander_text');

                                    if( $expanderTitle) :
                            ?>
    
                               <li>
                                    <div class="expander-title">
                                        <span class="num"><?php echo get_row_index(); ?></span>
                                        <h5>
                                            <?php echo $expanderTitle; ?>
                                        </h5>
                                        <span class="expander-icon"></span>
                                    </div>
                                    <div class="expander-text">
                                        <?php if( $expanderText ) : ?>
                                            <p><?php echo $expanderText; ?></p>
                                        <?php endif; ?>
                                    </div>
                               </li>
    
                            <?php endif; endwhile; ?>
                        </ul>
                    <?php endif;?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section><!-- Text Expander -->