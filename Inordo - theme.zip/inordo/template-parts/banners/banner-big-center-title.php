<?php $Title = get_sub_field('banner_big_center_title_title'); ?>

<div id="banner-big-center-title">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-12 col-sm-12 text-center">

                <?php if( $Title ): ?>
                    <div class="title">
                        <h1><?php echo $Title ?></h1>
                    </div>
                <?php endif; ?>
                
                <?php if( get_sub_field('banner_big_center_title_btn') ): ?>
                <!-- Button -->
                    <?php 
                        $link = get_sub_field('banner_big_center_title_btn');
                        if( $link ): 
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                            ?>
                            <div class="btn-box">
                                <button type="button" class="empty-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                    <?php echo esc_html( $link_title ); ?>
                                </button>
                                <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-bottom-arrow.svg') ?>" alt="">
                            </div>
                        <?php endif; ?>
                    <!-- End Button -->
                <?php endif; ?>

            </div>
        </div>
        
    </div>
</div>