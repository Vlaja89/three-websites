<footer>
    <div class="container">
        <div class="footer-box">
            <div class="row flex-wrap align-items-start justify-content-center">

                <!-- Col One -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="foot-title">
                        <p><?php the_field('menu_title', 'options') ?></p>
                    </div>
                    <div class="foot-menu">
                        <?php
                            if (has_nav_menu('menu_footer')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'menu_footer',
                                    'menu_class' => 'navbar-nav',
                                    'container' => 'ul'
                                ));
                            }
                        ?>
                    </div>
                </div>

                <!-- Col Two -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="social-media">
                        <?php if( have_rows('social_media', 'options') ): ?>
                            <?php while( have_rows('social_media', 'options') ): the_row(); ?>
                                <div class="single-media box-element">
                                    <p><a href="<?php the_sub_field('social_media_url', 'options') ?>" target="_blank"><?php the_sub_field('social_media_title', 'options') ?></a></p>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Col Three -->
                <div class="col-lg-4 col-md-6 col-sm-12">
                <div class="copyright">
                        <div class="copyright-desc">
                            <p><?php the_field('copyright', 'options') ?></p>
                        </div>
                        <div class="copyright-img">
                            <img src="<?php the_field('copyright_img', 'options') ?>" alt="">
                        </div>
                </div>
                </div>

            </div>
        </div>
    </div>

</footer>

<?php wp_footer(); ?>


</div>
</body>
</html>