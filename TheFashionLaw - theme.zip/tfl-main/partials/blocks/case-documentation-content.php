<?php

    // Case Documentation Content Block
    $className = 'case_documentation_content';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $left_side      = get_field('left_side');
    $right_side     = get_field('right_side');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
        
            <?php if ( $left_side ) : ?>
                <div class="left">
                    <?php echo $left_side; ?>
                </div>
            <?php endif; ?>

            <?php if ( $right_side ) : ?>
                <div class="right">
                    <?php echo $right_side; ?>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>