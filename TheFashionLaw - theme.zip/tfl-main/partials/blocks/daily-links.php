<?php

    // Daily Links Block
    $className = 'daily_links';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">

            <div class="small-title">
                <p class="category-article">Daily LInks</p>
            </div>

            <?php
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; // Get the current page number
            $all_posts_query = new WP_Query(array(
                'post_type' => 'daily_links',
                'posts_per_page' => 5, 
                'paged' => $paged // Set the current page
            ));

            while ($all_posts_query->have_posts()) :
                $all_posts_query->the_post();
                ?>

                <div class="link-post-box">
                    <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                        <div class="big-title main-post">
                            <h1>Daily Links: <?php echo get_the_date(); ?></h1>
                        </div>
                    </a>
                    <div class="single-links-content">
                        <?php the_content(); ?>
                    </div>
                </div>

            <?php endwhile; ?>

            <!-- Pagination -->
            <?php
            $total_pages = $all_posts_query->max_num_pages; // Get the total number of pages
            if ($total_pages > 1) {
                ?>
                <div class="custom-pagination">
                    <?php
                    echo paginate_links(array(
                        'base' => get_pagenum_link(1) . '%_%',
                        'format' => '/page/%#%', // Custom pagination format
                        'current' => $paged,
                        'total' => $total_pages,
                        'prev_text' => __('<img src="/wp-content/uploads/2023/06/blue-arrow-left.svg" alt="">'),
                        'next_text' => __('<img src="/wp-content/uploads/2023/06/blue-arrow-right.svg" alt="">'),
                    ));
                    ?>
                </div>
            <?php } ?>

        </div>
    </div>
</section>