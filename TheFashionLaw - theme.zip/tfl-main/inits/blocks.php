<?php

    /**
    * Register ACF blocks
    */

    function register_acf_block_types() {

        // Hero Block
        acf_register_block_type(array(
            'name'              => 'hero',
            'title'             => __('Page Hero'),
            'description'       => __('Page Hero block.'),
            'render_template'   => 'partials/blocks/hero.php',
            'category'          => 'common',
            'icon'              => 'superhero',
            'keywords'          => array( 'page hero'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, // Ovde menjas da li hoces da ima vise ili samo jedan blok, Hero obicno samo jedan
            ),
        ));

        // Small Title Descrtion Block
        acf_register_block_type(array(
            'name'              => 'Small Title and Description',
            'title'             => __('Small Title and Description'),
            'description'       => __('Small Title and Description block.'),
            'render_template'   => 'partials/blocks/small-title-and-description.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'small title description'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // Year and Month Subscribe Block
        acf_register_block_type(array(
            'name'              => 'Year Month Subscribe',
            'title'             => __('Year Month Subscribe'),
            'description'       => __('Year Month Subscribe.'),
            'render_template'   => 'partials/blocks/year-month-subscribe.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'year month subscribe'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        //Count Columns Block
        acf_register_block_type(array(
            'name'              => 'Count Columns',
            'title'             => __('Count Columns'),
            'description'       => __('Count Columns block.'),
            'render_template'   => 'partials/blocks/count-columns.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'count columns'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        //Textual Editor Block
        acf_register_block_type(array(
            'name'              => 'Textual Editor',
            'title'             => __('Textual Editor'),
            'description'       => __('Textual Editor block.'),
            'render_template'   => 'partials/blocks/textual-editor.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'textual editor'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        //Banner Block
        acf_register_block_type(array(
            'name'              => 'Banner',
            'title'             => __('Banner'),
            'description'       => __('Banner block.'),
            'render_template'   => 'partials/blocks/banner.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'banner'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        //Line Divider Block
        acf_register_block_type(array(
            'name'              => 'Line Divider',
            'title'             => __('Line Divider'),
            'description'       => __('Line Divider block.'),
            'render_template'   => 'partials/blocks/line-divider.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'line divider'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Text & Expander Block
        acf_register_block_type(array(
            'name'              => 'Text Expander',
            'title'             => __('Text Expander'),
            'description'       => __('Text Expander block.'),
            'render_template'   => 'partials/blocks/text-expander.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'text expander'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Text & Image Block
        acf_register_block_type(array(
            'name'              => 'Text Image',
            'title'             => __('Text Image'),
            'description'       => __('Text Image block.'),
            'render_template'   => 'partials/blocks/text-image.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'text image'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // List Text Block
        acf_register_block_type(array(
            'name'              => 'List Text',
            'title'             => __('List Text'),
            'description'       => __('List Text block.'),
            'render_template'   => 'partials/blocks/list-text.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'list text'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Spacer Block
        acf_register_block_type(array(
            'name'              => 'Spacer',
            'title'             => __('Spacer'),
            'description'       => __('Spacer block.'),
            'render_template'   => 'partials/blocks/spacer.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'spacer'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Quote Block
        acf_register_block_type(array(
            'name'              => 'Quote',
            'title'             => __('Quote'),
            'description'       => __('Quote block.'),
            'render_template'   => 'partials/blocks/quote.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'quote'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Title & Description Block
        acf_register_block_type(array(
            'name'              => 'Title and Description',
            'title'             => __('Title and Description'),
            'description'       => __('Title and Descriptionn block.'),
            'render_template'   => 'partials/blocks/title-and-description.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'title description'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // Blue Green Block
        acf_register_block_type(array(
            'name'              => 'Blue Green Box',
            'title'             => __('Blue Green Box'),
            'description'       => __('Blue Green Box block.'),
            'render_template'   => 'partials/blocks/blue-green-box.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'blue green box'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // FAQ Block
        acf_register_block_type(array(
            'name'              => 'FAQ',
            'title'             => __('FAQ'),
            'description'       => __('FAQx block.'),
            'render_template'   => 'partials/blocks/faq.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'faq'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // Student Subscriptions Block
        acf_register_block_type(array(
            'name'              => 'Student Subscriptions',
            'title'             => __('Student Subscriptions'),
            'description'       => __('Student Subscriptions block.'),
            'render_template'   => 'partials/blocks/student-subscriptions.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'student subscriptions'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // Daily Links Block
        acf_register_block_type(array(
            'name'              => 'Daily Links',
            'title'             => __('Daily Links'),
            'description'       => __('Daily Links block.'),
            'render_template'   => 'partials/blocks/daily-links.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'daily links'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Proprietary Data Sets Block
        acf_register_block_type(array(
            'name'              => 'Proprietary Data Sets',
            'title'             => __('Proprietary Data Sets'),
            'description'       => __('Proprietary Data Sets block.'),
            'render_template'   => 'partials/blocks/proprietary-data-sets.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'proprietary data sets'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
        
        // Deep Dives Block
        acf_register_block_type(array(
            'name'              => 'Deep Dives',
            'title'             => __('Deep Dives'),
            'description'       => __('Deep Dives block.'),
            'render_template'   => 'partials/blocks/deep-dives.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'deep dives'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Weekly Briefings Block
        acf_register_block_type(array(
            'name'              => 'Weekly Briefings',
            'title'             => __('Weekly Briefings'),
            'description'       => __('Weekly Briefings block.'),
            'render_template'   => 'partials/blocks/weekly-briefings.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'weekly briefings'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Case Documentation Block
        acf_register_block_type(array(
            'name'              => 'Case Documentation',
            'title'             => __('Case Documentation'),
            'description'       => __('Case Documentation block.'),
            'render_template'   => 'partials/blocks/case-documentation.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'case documentation'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Reports & Trackers Block
        acf_register_block_type(array(
            'name'              => 'Reports Trackers',
            'title'             => __('Reports Trackers'),
            'description'       => __('Reports Trackers block.'),
            'render_template'   => 'partials/blocks/reports-trackers.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'reports trackers'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Case Briefs Block
        acf_register_block_type(array(
            'name'              => 'Case Briefs',
            'title'             => __('Case Briefs'),
            'description'       => __('Case Briefs block.'),
            'render_template'   => 'partials/blocks/case-briefs.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'case briefs'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

        // Topics of Interest Block
        acf_register_block_type(array(
            'name'              => 'Topics of Interest',
            'title'             => __('Topics of Interest'),
            'description'       => __('Topics of Interest block.'),
            'render_template'   => 'partials/blocks/topics-of-interest.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'topics of interest'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));

         // Case Documentation Block
         acf_register_block_type(array(
            'name'              => 'Case Documentation Content',
            'title'             => __('Case Documentation Content'),
            'description'       => __('Case Documentation block.'),
            'render_template'   => 'partials/blocks/case-documentation-content.php',
            'category'          => 'common',
            //'icon'              => ' ',
            'keywords'          => array( 'case documentation content'),
            'mode'	            => 'edit',
            'supports' 			=> array(
                'multiple'      => true, 
            ),
        ));
    }
    
    // Check if function exists and hook into setup.
    if (function_exists('acf_register_block_type')) {
        add_action('acf/init', 'register_acf_block_types');
    }