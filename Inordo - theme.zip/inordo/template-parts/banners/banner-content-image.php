<?php $Title = get_sub_field('banner_content_image_title'); ?>
<?php $Desc = get_sub_field('banner_content_image_desc'); ?>
<?php $Image = get_sub_field('banner_content_image_img'); ?>

<div id="banner-content-image">
    <div class="container">

        <div class="row flex wrap align-items-center">
            <div class="col-lg-7 col-md-12 col-sm-12 section-order-1">

                <div class="banner-content">
                    <?php if( $Title ): ?>
                        <div class="title big-title">
                            <h2><?php echo $Title ?></h2>
                        </div>
                    <?php endif; ?>
                    
                    <?php if( $Desc ): ?>
                        <div class="desc">
                            <?php echo $Desc ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-lg-5 col-md-12 col-sm-12 section-order-2">

                <?php if( $Image ): ?>
                    <div class="image">
                        <img src="<?php echo $Image ?>" alt="" class="img-fluid">
                    </div>
                <?php endif; ?>

            </div>
        </div>
        
    </div>
</div>