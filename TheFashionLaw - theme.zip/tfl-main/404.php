<?php
/**
 * The template for displaying 404 pages (not found)
  */
get_header();
?>
<section class="inner-hero" style="min-height: 70vh; display: flex; align-items: center; justify-content: center;  text-align: center;">
    <div class="section-width">
        <div class="error-404 not-foundr">
            <h2 class="general" style="margin-bottom: 30px;"><?php _e('Oops! That page can&rsquo;t be found.', 'glion'); ?></h2>
            <button type="button" onclick="location.href='<?php echo get_home_url(); ?>';" class="btn-blue">Go To Home Page</button>
        </div><!-- .error-404 -->
    </div>
</section>
<?php get_footer(); ?>
