<?php

    // List With Text Block
    $className = 'list_text';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

?>

<section class="<?php echo esc_attr($className); ?> section-width">
    <div class="wrapper">
        <div class="holder">
        
        <?php if( get_field('text_list') ): ?>
            <?php if( have_rows('text_list') ): ?>
                <?php while( have_rows('text_list') ) : the_row(); ?>
                    <div class="single-text">
                        <?php
                            $link = get_sub_field('text_list_text');
                            if( $link ):
                                $link_url = $link['url'];
                                $link_title = $link['title'];
                        ?>
                        <h2 class="general"><a href="<?php echo esc_url( $link_url ); ?>"><?php echo esc_html( $link_title ); ?></a></h2>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        <?php endif; ?>

        </div>
    </div>
</section><!-- Text List -->