<?php get_header(); ?>

<div id="wrapp">

    <div id="post-content">
        <div class="container">

            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

                <div class="single-post-container">
                    

                    <div class="post-banner small-width-post">
                        <div class="d-flex align-items-center">
                            <div class="cayrgory box-element">
                                <?php
                                    $categories = get_the_category(); // Get all categories for the current post
                                    if ($categories) {
                                        $primary_category = $categories[0]; // Get the first category (primary category)
                                        echo '<p><a href="' . get_category_link($primary_category->cat_ID) . '">' . $primary_category->cat_name . '</a></p>';
                                    }
                                ?>
                            </div>
                            <div class="date">
                                <p><?php echo get_the_date(); ?></p>
                            </div>
                        </div>
                        <div class="top-info">
                            <div class="title big-title">
                                <h3><?php the_title(); ?></h3>
                            </div>
                            <div class="person-info-box">
                                <div class="person-box">
                                    <div class="person-img">
                                        <img src="<?php the_field('main_author_img', 'option') ?>" alt="">
                                    </div>
                                    <div class="person-info top-title">
                                        <div class="person-name">
                                            <p><?php the_field('main_author_name', 'option') ?></p>
                                        </div>
                                        <div class="person-position">
                                            <p><?php the_field('main_author_position', 'option') ?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="top-title read-time">
                                    <?php
                                        $mycontent = $post->post_content;
                                        $word_count = str_word_count(strip_tags($mycontent));
                                        $average_reading_speed = 250; // Adjust this value as needed (words per minute)
                                        
                                        $minutes = ceil($word_count / $average_reading_speed);
                                        $est = $minutes . ' min' . ($minutes == 1 ? '' : 's');
                                    ?>

                                    <p>Time to read:</p>
                                    <h5><?php echo $est; ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="single-blog-img">
                        <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title();?>" class="img-fluid mb-3">
                    </div>
                    
                    <div class="post-content small-width-post">
                        <div class="excerpt">
                            <p><?php echo get_the_excerpt(); ?></p>
                        </div>
                        <?php the_content(); ?>
                    </div>
                    
                </div>

                <?php endwhile; ?>
            <?php endif; ?>

            <div class="main-post-author small-width-post">
                <div class="img">
                    <img src="<?php the_field('main_author_img', 'option') ?>" alt="">
                </div>
                <div class="name">
                    <p><?php the_field('main_author_name', 'option') ?></p>
                </div>
                <div class="position">
                    <p><?php the_field('main_author_position', 'option') ?></p>
                </div>
                <div class="desc">
                    <p><?php the_field('main_author_desc', 'option') ?></p>
                </div>
                <div class="social-media">
                    <?php if( have_rows('main_author_media', 'option') ): ?>
                        <?php while( have_rows('main_author_media', 'option') ): the_row(); ?>
                            <div class="single-media">
                                <a href="<?php the_sub_field('main_author_media_url', 'option') ?>" target="_blank">
                                    <img src="<?php the_sub_field('main_author_media_icon', 'option') ?>" alt="">
                                </a>
                            </div>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="single-post-container">
                <div class="other-posts posts-box">
                    <div class="main-title">
                        <div class="title big-title">
                            <h3>Other Articles</h3>
                        </div>
                        <div class="btn-box">
                            <button type="button" class="dark-custom-btn" onclick="location.href='/blog';">
                                View all blogs
                            </button>
                            <img src="<?php echo get_theme_file_uri('./dist/img/red-circle-white-arrow-top.svg') ?>" alt="">
                        </div>
                    </div>
                    <?php    
                        $args = array(
                            'post_type' => 'post',
                            'orderby' => 'rand',
                            'posts_per_page' => 3,
                            'post_status' => 'publish'
                            );

                        $the_query = new WP_Query($args);
                        if ( $the_query->have_posts() ) {
                            while ( $the_query->have_posts() ) {
                                $the_query->the_post(); ?>


                                <div class="single-post">
                                    <div class="post-info">
                                        <div class="d-flex align-items-center">
                                            <div class="cayrgory box-element">
                                                <p>
                                                    <?php 
                                                        foreach(get_the_category() as $category) {
                                                            echo '<p><a href="'.get_category_link($category->cat_ID).'">'.$category->cat_name.'</a></p>';
                                                    } ?>
                                                </p>
                                            </div>
                                            <div class="date">
                                                <p><?php echo get_the_date(); ?></p>
                                            </div>
                                        </div>
                                        <div class="post-name">
                                            <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                                <h3><?php the_title(); ?></h3>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="arrow-link">
                                        <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                            <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-arrow.svg') ?>" alt="">
                                        </a>
                                    </div>
                                </div>


                        <?php }
                        } else {
                            // no posts found
                        }
                        wp_reset_postdata();
                    ?>
                </div>
            </div>
           
        </div>
    </div>
    
</div>
     
<?php get_footer(); ?>