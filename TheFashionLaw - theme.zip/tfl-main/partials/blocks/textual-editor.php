<?php

    // Textual Editor Block
    $className = 'textual_editor';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $textual_editor  = get_field('textual_editor');

    if( $textual_editor ) :

    // Mission and values Ethic policy, Vidi ovo dole sto sam dopisao comment
?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
            <div class="textual-editor">
                <?php echo $textual_editor; ?>
                <!-- Ovde mozemo da ispucavamo globalne stilove h1,h2, p, quote itd. A za ovu klasu textual-editor mozemo da se vezemo oko sredjivanja ul, ol li itd -->
            </div>
        </div>
    </div>
</section><!-- Textual Editor -->

<?php endif; ?>