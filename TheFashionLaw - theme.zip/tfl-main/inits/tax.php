<?php 
/**
 * Custom taxonomies
 *
 * @package starter_wp_theme
 */

// People taxonomy - CATEGORIES
// function create_people_cat_taxonomy() {
//   $labels = array(
//     'name' 						=> _x( 'Categories', 'taxonomy general name','hawken_wp_theme' ),
//     'singular_name' 			=> _x( 'Category', 'taxonomy singular name','hawken_wp_theme' ),
//     'search_items' 				=> __( 'Search categories','hawken_wp_theme'),
//     'all_items' 				=> __( 'All categories','hawken_wp_theme' ),
//     'parent_item' 				=> __( 'Parent category','hawken_wp_theme'),
//     'parent_item_colon' 		=> __( 'Parent category:','hawken_wp_theme' ),
//     'edit_item'	 				=> __( 'Edit category','hawken_wp_theme'), 
//     'update_item' 				=> __( 'Updste category','hawken_wp_theme' ),
//     'add_new_item' 				=> __( 'Add new category','hawken_wp_theme'),
//     'new_item_name'				=> __( 'New category','hawken_wp_theme' ),
//     'menu_name' 				=> __( 'Categories','hawken_wp_theme' ),
//   ); 	
 
//   register_taxonomy('cats',array('people'), array(
//     'hierarchical' 				=> true,
//     'labels' 					=> $labels,
//     'show_ui' 					=> true,
// 	'has_archive' 				=> false,
//     'show_admin_column' 		=> true,
// 	'publicly_queryable'		=> false,
//   ));
// }
// add_action( 'init', 'create_people_cat_taxonomy', 0 );

