<?php get_header(); ?>
<div id="wrapp">

    <!-- Search Content -->
    <div class="search-page" id="woo-products">
        <div class="container">
            
            <div class="title text-center">
                <h3>Search Results for </br> <span style="color: #D20B10;">'<?php the_search_query(); ?>'</span></h3>
            </div>

            <div class="woo-products">
                <div class="row flex-wrap align-items-center justify-content-center">

                    <?php if (have_posts()): ?>
                        <?php while (have_posts()): ?>
                            <?php the_post(); ?>

                            <?php if (get_post_type() == 'product'): ?>
                               <div class="col-lg-3 col-md-6 col-sm-12">
                                    <div class="single-product-box">
                                        <div class="product-img">
                                            <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                        </div>
                                        <div class="product-info">
                                            <div class="product-desc">
                                                <?php $short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt ); ?>
                                                <?php echo $short_description; ?>
                                            </div>
                                            <div class="product-price">
                                                <?php $price = get_post_meta( get_the_ID(), '_price', true ); ?>
                                                <p><?php echo wc_price( $price ); ?></p>
                                            </div>
                                            <div class="product-btn">
                                                <?php
                                                    global $product;
                                                    $product_id = $product->get_id();
                                                    $product_object = wc_get_product( $product_id );
                                                ?>
                                                <button type="button" class="red-custom-btn" onclick="location.href='<?php echo esc_url( $product_object->add_to_cart_url() ); ?>';">
                                                    <?php echo esc_html__( 'Add to basket', 'text-domain' ); ?>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                               </div>
                            <?php else: ?>
                                <!-- Blog Post or Different content-->
                            <?php endif; ?>

                        <?php endwhile; else: ?>

                        <!-- If there are no search results, display this message. Before adding this, you must create a new template in includes folder (section-searchresults.php). Copy and paste the whole code from the Archive template and change the root -->
                        <div class="text-center">
                            <p><strong>There are no search results for <span style="color: #C9433C;">'<?php the_search_query(); ?>'</span></strong></p>
                        </div>
                            
                    <?php endif; ?>

                </div>

                <!-- Pagination with numbers -->
                <div class="custom-pagination">
                    <?php
                        global $wp_query;
                        $big = 999999999; // need an unlikely integer

                        echo paginate_links( array(
                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'total' => $wp_query->max_num_pages
                        ) );
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php get_footer(); ?>
