<?php $Title = get_sub_field('content_list_main_title'); ?>
<?php $Desc = get_sub_field('content_list_desc'); ?>

<div id="content-list">
    <div class="container">

        <div class="row flex wrap align-items-center">
            <div class="col-lg-6 col-md-12 col-sm-12">

                <?php if( $Title ): ?>
                    <div class="title big-title">
                        <h2><?php echo $Title ?></h2>
                    </div>
                <?php endif; ?>

            </div>
            <div class="offset-lg-1 col-lg-5 col-md-12 col-sm-12">
                <?php if( $Desc ): ?>
                    <div class="desc">
                        <?php echo $Desc ?>
                    </div>
                <?php endif; ?>
                
                <div class="list">
                    <?php if( have_rows('content_list') ): ?>
                        <?php while( have_rows('content_list') ): the_row(); ?>

                            <div class="single-list box-element">
                                <p><?php the_sub_field('content_list_title'); ?></p>
                            </div>
                        
                        <?php endwhile; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        
    </div>
</div>