<?php $Title = get_sub_field('big_center_title_title'); ?>

<div id="big-center-title">
    <div class="container">

        <div class="big-center-title-box">
            <?php if( $Title ): ?>
                <div class="title big-title">
                    <h2><?php echo $Title ?></h2>
                </div>
            <?php endif; ?>
            
            <?php if( get_sub_field('big_center_title_btn') ): ?>
            <!-- Button -->
                <?php 
                    $link = get_sub_field('big_center_title_btn');
                    if( $link ): 
                        $link_url = $link['url'];
                        $link_title = $link['title'];
                        ?>
                        <div class="btn-box">
                            <button type="button" class="dark-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                <?php echo esc_html( $link_title ); ?>
                            </button>
                            <img src="<?php echo get_theme_file_uri('./dist/img/red-circle-white-arrow-top.svg') ?>" alt="">
                        </div>
                    <?php endif; ?>
                <!-- End Button -->
            <?php endif; ?>
        </div>
        
    </div>
</div>



