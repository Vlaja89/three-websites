<?php get_header(); ?>

<div id="wrapp">

    <div id="service-content">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

            <?php if( have_rows('content') ):
                while ( have_rows('content') ) : the_row(); ?>

                    <?php  if( get_row_layout() == 'big_banner' ): ?>
                    <!-- Big Banner -->

                        <?php get_template_part('template-parts/banners/big-banner'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'small_banner' ): ?>
                    <!-- Small Banner -->
                    
                        <?php get_template_part('template-parts/banners/small-banner'); ?>
                        
                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'text_and_image' ): ?>
                    <!-- Text & Image -->

                        <?php get_template_part('template-parts/sections/text-image'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'image_and_text' ): ?>
                    <!-- Image & Text -->

                        <?php get_template_part('template-parts/sections/image-text'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'gallery' ): ?>
                    <!-- Gallery -->

                        <?php get_template_part('template-parts/sections/gallery'); ?>
                        
                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'full_text_and_image' ): ?>
                    <!-- Full Text & Image -->

                        <?php get_template_part('template-parts/sections/full-text-image'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'full_image_and_text' ): ?>
                    <!-- Full Image & Text  -->

                        <?php get_template_part('template-parts/sections/full-image-text'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'woo_products' ): ?>
                    <!-- Woo Products  -->

                        <?php get_template_part('template-parts/sections/woo-products'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'woo_products_yanmar' ): ?>
                    <!-- Woo Products Yanmar -->

                        <?php get_template_part('template-parts/sections/woo-products-yanmar'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'full_bg_image' ): ?>
                    <!-- Full Bg Image  -->

                        <?php get_template_part('template-parts/sections/full-bg-image'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'services' ): ?>
                    <!-- Services  -->

                        <?php get_template_part('template-parts/sections/services'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'contact_promotion' ): ?>
                    <!-- Contact Promotion  -->

                        <?php get_template_part('template-parts/options/contact-promotion'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'big_text_over_image' ): ?>
                    <!-- Big Text Over Image  -->

                        <?php get_template_part('template-parts/sections/big-text-over-image'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'testimonials' ): ?>
                    <!-- Testimonials  -->

                        <?php get_template_part('template-parts/sections/testimonials'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'contact' ): ?>
                    <!-- Contact  -->

                        <?php get_template_part('template-parts/sections/contact'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'map' ): ?>
                    <!-- Map  -->

                        <?php get_template_part('template-parts/sections/map'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'sticky_menu_section' ): ?>
                    <!-- Sticky Menu Section  -->

                        <?php get_template_part('template-parts/sections/sticky-menu-section'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'half_content' ): ?>
                    <!-- Half Content  -->

                        <?php get_template_part('template-parts/sections/half-content'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'icon_column' ): ?>
                    <!-- Icon Column  -->

                        <?php get_template_part('template-parts/sections/icon-column'); ?>

                    <?php endif; ?>

                    <?php  if( get_row_layout() == 'text_and_pdf' ): ?>
                    <!-- Text and PDF  -->

                        <?php get_template_part('template-parts/sections/text-and-pdf'); ?>

                    <?php endif; ?>

                <?php  endwhile; ?>
                <?php else : ?>
            <?php endif; ?>

            <?php endwhile; ?>
        <?php endif; ?>

    </div>
</div>
     
<?php get_footer(); ?>