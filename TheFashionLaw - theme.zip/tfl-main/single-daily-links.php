<?php get_header(); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

		<div class="single-links-banner section-width">
            <div class="link-post-box">
					
				<div class="single-links-desc">
					<div class="small-title">
						<p class="category-article">Daily LInks</p>
					</div>
					<div class="big-title main-post">
						<h1>Daily Links: <?php echo get_the_date(); ?></h1>
					</div>
				</div>
				
				<div class="single-links-content">
					<?php the_content(); ?>
				</div>

			</div>
		</div>

		<!-- Related Posts -->
		<div class="realted-posts container-width">
			<div class="realted-posts-title blue-box-title">
				<p>related articles</p>
			</div>
			<div class="realted-posts-box">
				<?php
					$postLinks = new WP_Query(array(
						'post_type' => 'daily-links',
						'posts_per_page' => 4,
						'orderby' => 'rand'
					));
				?>

				<?php if ($postLinks->have_posts()) : 
					while ($postLinks->have_posts()) : 
					$postLinks->the_post(); ?>

						<div class="col-lg-3 col-md-6 col-sm-12">
							<div class="single-links-desc">
                   				<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
									<div class="small-title">
										<p class="category-article">Daily LInks</p>
									</div>
									<div class="big-title">
										<h2>Daily Links: <?php echo get_the_date(); ?></h2>
									</div>
									<div class="single-links-content">
										<p>
											<?php
												$content = get_the_content(); // Retrieve the post content
												$trimmed_content = wp_trim_words($content, 20, ' ...'); // Trim the content to 50 words
												echo $trimmed_content; // Display the trimmed content
											?>
										</p>
									</div>
									<div class="date-author">
										<p><?php echo get_the_date(); ?> - 
											<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">By <?php the_author(); ?></a>
										</p>
									</div>
								</a>
							</div>
						</div>
					
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				<?php endif; ?>
			</div>
		</div>
		<!-- End Related Posts -->

	<?php endwhile; endif; ?>

<?php get_footer(); ?>