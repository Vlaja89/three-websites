<?php $Title = get_sub_field('woo_products_title'); ?>
<?php $Content = get_sub_field('woo_products_description'); ?>

<section id="woo-products">
    <div class="container">
        <div class="row flex-wrap align-items-center">
            <div class="col-lg-6 col-md-6 col-sm-12">
                <?php if( $Title ): ?>
                    <div class="title">
                        <h3><?php echo $Title ?></h3>
                    </div>
                <?php endif; ?>
                <?php if( $Content ): ?>
                    <div class="description">
                        <?php echo $Content ?>
                    </div>
                <?php endif; ?>
                <?php if( get_sub_field('woo_products_btn') ): ?>
                <!-- Button -->
                    <?php 
                        $link = get_sub_field('woo_products_btn');
                        if( $link ): 
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                            ?>
                            <button type="button" class="custom-link" onclick="location.href='<?php echo esc_url( $link_url ); ?>';"><?php echo esc_html( $link_title ); ?></button>
                        <?php endif; ?>
                    <!-- End Button -->
                <?php endif; ?>
            </div>
        </div>

        <div class="woo-products woo-slider">
            <?php
                $woo_products = get_sub_field('woo_product');
                if( $woo_products ): ?>
                    <?php foreach( $woo_products as $post ): 
                        $short_description = apply_filters( 'woocommerce_short_description', $post->post_excerpt );
                        $price = get_post_meta( get_the_ID(), '_price', true );
                        

                        // Setup this post for WP functions (variable must be named $post).
                        setup_postdata($post); ?>
                        <div class="single-product-box">
                            <div class="product-img">
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid">
                                <?php else : ?>
                                    <img src="default-image.jpg" alt="Default Image" class="img-fluid">
                                <?php endif; ?>
                            </div>
                            <div class="product-info">
                                <div class="product-desc">
                                    <?php echo $short_description; // WPCS: XSS ok. ?>
                                </div>
                                <div class="product-price">
                                    <p><?php echo wc_price( $price ); ?></p>
                                </div>
                                <div class="product-btn">
                                    <?php
                                        global $product;
                                        $product_id = $product->get_id();
                                        $product_object = wc_get_product( $product_id );
                                    ?>
                                    <button type="button" class="red-custom-btn" onclick="location.href='<?php echo esc_url( $product_object->add_to_cart_url() ); ?>';">
                                        <?php echo esc_html__( 'Add to basket', 'text-domain' ); ?>
                                    </button>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>
                <?php 
                // Reset the global post object so that the rest of the page works correctly.
                wp_reset_postdata(); ?>
            <?php endif; ?>
    </div>
            
    </div>
</section>