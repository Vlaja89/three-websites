<?php

/**
 * Page Hero Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create class attribute allowing for custom "className" and "align" values.
$className = 'hero';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}

$subtitle   = get_field('subtitle');
$text       = get_field('text');
$image      = get_field('image');
$overlay    = get_field('image_overlay');
$opacity    = $overlay / 100;

?>

<section class="<?php echo esc_attr($className); ?> has_bgr" style="background-image: url(<?php echo $image['url']; ?>);">
    <article>

        <?php if ( $subtitle ) : ?>
            <h6 class="animated anim_y section_subtitle"><?php echo $subtitle; ?></h6>
        <?php endif; ?>

        <?php if ( $text ) : ?>
            <h1 class="animated anim_y section_title"><?php echo $text; ?></h1>
        <?php endif; ?>

    </article>
    <div class="img_overlay" style="opacity: <?php echo $opacity; ?>"></div>
</section><!-- /Hero -->