<?php $Form = get_sub_field('contact_form'); ?>
<?php $Info = get_sub_field('contact_info'); ?>

<section id="contact-box">
    <div class="container">
        <div class="row flex-wrap align-items-start">
            <div class="col-lg-8 col-md-12 col-sm-12 section-order-1">
                <?php if( $Form ): ?>
                    <div class="contact-form">
                        <?php echo $Form ?>
                    </div>
                <?php endif; ?>
            </div>
            <div class="offset-lg-1 col-lg-3 col-md-12 col-sm-12 section-order-2">
                <?php if( $Info ): ?>
                    <div class="description">
                        <?php echo $Info ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>