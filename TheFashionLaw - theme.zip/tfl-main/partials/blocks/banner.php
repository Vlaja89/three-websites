<?php

/**
 * Banner Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create class attribute allowing for custom "className" and "align" values.
$className = 'banner';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}

$title   = get_field('subtitle');
$link    = get_field('link');

// recimo na subscribe stranici. imace ovaj blok uvek isti gradijent, samo ce se menjati title i link

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">

            <?php if ($title) : ?>
                <h4><?php echo $title; ?></h4>
            <?php endif; ?>

            <?php if ($link) : ?>
                <a href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>" class="link"><?php echo $link['title']; ?></a>
            <?php endif; ?>

        </div>
    </div>
</section><!-- /Banner -->