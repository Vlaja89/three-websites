<?php $Title = get_sub_field('post_main_title'); ?>

<section id="posts">
    <div class="container">

       <div class="main-title">
            <?php if( $Title ): ?>
                <div class="title big-title">
                    <h3><?php echo $Title ?></h3>
                </div>
            <?php endif; ?>
            
            <div class="post-btn">
                <?php if( get_sub_field('post_btn') ): ?>
                <!-- Button -->
                    <?php 
                        $link = get_sub_field('post_btn');
                        if( $link ): 
                            $link_url = $link['url'];
                            $link_title = $link['title'];
                            ?>
                            <div class="btn-box">
                                <button type="button" class="dark-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';">
                                    <?php echo esc_html( $link_title ); ?>
                                </button>
                                <img src="<?php echo get_theme_file_uri('./dist/img/red-circle-white-arrow-top.svg') ?>" alt="">
                            </div>
                        <?php endif; ?>
                    <!-- End Button -->
                <?php endif; ?>
            </div>

       </div>

       <div class="posts-box">

       <?php
            $query = new WP_Query(array(
                'posts_per_page' => 6,
                'post_type' => 'post',
                'order' => 'DESC',
                'post_status' => 'publish'
            ));
            ?>

            <?php if ($query->have_posts()) : ?>
                <!-- loop -->
                <?php while ($query->have_posts()) : $query->the_post(); ?>

                    <div class="single-post">
                        <div class="post-info">
                            <div class="d-flex align-items-center">
                                <div class="category-name box-element">
                                    <?php
                                    $categories = get_the_category();
                                    if ($categories) {
                                        $primary_category = $categories[0];
                                        echo '<p><a href="' . esc_url(get_category_link($primary_category->cat_ID)) . '">' . esc_html($primary_category->cat_name) . '</a></p>';
                                    }
                                    ?>
                                </div>
                                <div class="date">
                                    <p><?php echo esc_html(get_the_date()); ?></p>
                                </div>
                            </div>
                            <div class="post-name">
                                <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
                                    <h3><?php the_title(); ?></h3>
                                </a>
                            </div>
                        </div>
                        <div class="arrow-link">
                            <a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>">
                                <img src="<?php echo esc_url(get_theme_file_uri('/dist/img/circle-black-arrow.svg')); ?>" alt="">
                            </a>
                        </div>
                    </div>

                <?php endwhile; ?>

                <?php wp_reset_postdata(); ?>

            <?php else : ?>
                <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
            <?php endif; ?>

       </div>

    </div>
</section>
