<?php $Title = get_sub_field('main_contact_main_title'); ?>
<?php $Desc = get_sub_field('main_contact_description'); ?>
<?php $Info = get_sub_field('main_contact_info'); ?>
<?php $Form = get_sub_field('main_form'); ?>

<section id="contact-form" class="main-contact-form">
    <div class="container">

        <div class="row flex-wrap align-items-start">
            <div class="col-lg-5 col-md-12 col-sm-12">
                <div class="contact-info">
                    <?php if( $Title ): ?>
                        <div class="title big-title">
                            <h2><?php echo $Title ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if( $Desc ): ?>
                        <div class="content">
                            <?php echo $Desc ?>
                        </div>
                    <?php endif; ?>
                    <?php if( $Info ): ?>
                        <div class="desc">
                            <?php echo $Info ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="offset-lg-1 col-lg-6 col-md-12 col-sm-12">
                <?php if( $Form ): ?>
                    <div class="form-box">
                        <?php echo $Form ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>
