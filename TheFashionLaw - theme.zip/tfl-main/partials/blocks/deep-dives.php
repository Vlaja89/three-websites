<?php

    // Deep Dives Block
    $className = 'deep_dives';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('deep_dives_title');
    $text       = get_field('deep_dives_description');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
        
            <div class="row-width">
                <div class="text col-width">
                    <?php if ($title) : ?>
                        <h1><?php echo $title; ?></h1>
                    <?php endif; ?>

                    <?php if ($text) : ?>
                        <h2><?php echo $text; ?></h2>
                    <?php endif; ?>
                </div>

                <div class="content col-width">
                    <?php
                        $args = array(
                            'post_type'      => 'page',
                            'posts_per_page' => -1,
                            'meta_query'     => array(
                                array(
                                    'key'     => 'page_type',
                                    'value'   => 'deep-dives',
                                    'compare' => 'LIKE'
                                )
                            )
                        );

                        $query = new WP_Query($args);

                        if ($query->have_posts()) {
                            // Create an array to store posts by year
                            $posts_by_year = array();

                            while ($query->have_posts()) {
                                $query->the_post();
                                global $post;

                                // Get the year of the current post
                                $post_year = get_the_date('Y');

                                // Add the post to the respective year array
                                if (!isset($posts_by_year[$post_year])) {
                                    $posts_by_year[$post_year] = array();
                                }
                                $posts_by_year[$post_year][] = $post;
                            }

                            // Loop through the posts by year and display them
                            foreach ($posts_by_year as $year => $posts) { ?>

                                <div class="post-year-box">
                                    <h2><strong><?php echo $year ?></strong></h2>

                                    <?php foreach ($posts as $post) {
                                        setup_postdata($post);
                                        ?>

                                        <h6>
                                            <a href="<?php echo get_permalink($post->ID) ?>">
                                                <span><?php echo get_the_date('M. Y') ?>: </span>
                                                <?php echo get_the_title() ?>
                                            </a>
                                        </h6>

                                        <?php
                                    } ?>
                                </div>
                                
                           <?php }
                        }

                        wp_reset_postdata();
                    ?>
                </div>
            </div>

        </div>
    </div>
</section><!-- Text List -->