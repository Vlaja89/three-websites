<?php

    // Proprietary Data Sets Block
    $className = 'proprietary_data_sets';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('proprietary_data_sets_title');
    $text       = get_field('proprietary_data_sets_description');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
        
            <div class="row-width">
                <div class="text col-width">
                    <?php if ($title) : ?>
                        <h1><?php echo $title; ?></h1>
                    <?php endif; ?>

                    <?php if ($text) : ?>
                        <h2><?php echo $text; ?></h2>
                    <?php endif; ?>
                </div>

                <div class="content col-width">
                    <?php $args = array(
                        'post_type'      => 'page',
                        'meta_query'     => array(
                            array(
                                'key'     => 'page_type', 
                                'value'   => 'proprietary-data-sets',
                                'compare' => 'LIKE'
                            )
                        )
                    );
                    
                    $query = new WP_Query($args);

                    if ($query->have_posts()) {
                        while ($query->have_posts()) {
                            $query->the_post();
                            global $post;  ?>

                            <h6><a href="<?php echo get_permalink($post->ID) ?>"><?php echo get_the_title() ?></a></h6>

                    <?php }
                    }
                    wp_reset_postdata();?>
                </div>
            </div>

        </div>
    </div>
</section>