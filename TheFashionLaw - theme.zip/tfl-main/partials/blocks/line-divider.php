<?php
    // Title & Description Block
    $className = 'line_divider';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $dividerBgr   = get_field('divider_bgr');
    $dividerHeight = get_field('divider_height');

?>

<div class="divider-line" style="background-color: <?php echo $dividerBgr; ?>; height: <?php echo $dividerHeight; ?>px">
</div><!-- Divider Line -->