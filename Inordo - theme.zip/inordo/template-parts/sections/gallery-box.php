<?php $Title = get_sub_field('gallery_main_title'); ?>

<div id="gallery-box">
    <div class="container">
        <?php if( $Title ): ?>
            <div class="title">
                <h5><?php echo $Title ?></h5>
            </div>
        <?php endif; ?>
    </div>

    <div class="container-fluid p-0">
        <div class="gallery-slider">
            <?php $images = get_sub_field('gallery_imgs'); ?>
            <?php if( $images ): ?>
                <?php foreach( $images as $image ): ?>
                    <div class="img-box">
                        <img src="<?php echo $image['sizes']['large']; ?>" alt="" class="img-fluid"/>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

</div>