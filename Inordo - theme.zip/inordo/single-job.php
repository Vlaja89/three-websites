<?php get_header(); ?>

<div id="wrapp">

    <div class="container">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>

                <div class="small-width-job">

                    <div class="top-info">
                        <div class="title">
                            <h2><?php the_title(); ?></h2>
                        </div>

                        <div class="job-info-bar">
                            <div class="top-title">
                                <p>Location</p>
                                <h5><?php the_field('job_location'); ?></h5>
                            </div>
                            <div class="top-title">
                                <p>Job Type</p>
                                <h5><?php the_field('job_type'); ?></h5>
                            </div>
                            <div class="top-title">
                                <p>Experience</p>
                                <h5><?php the_field('job_experience'); ?></h5>
                            </div>
                        </div>
                    </div>
            
                    <?php if( have_rows('job_content') ):
                        while ( have_rows('job_content') ) : the_row(); ?>

                            <?php $Content = get_sub_field('job_description'); ?>

                            <div class="job-content">
                                <?php echo $Content; ?>
                            </div>

                            <?php endwhile; ?>
                        <?php else : ?>
                    <?php endif; ?>

                </div>

            <?php endwhile; ?>
        <?php endif; ?>


        <div class="job-form-box small-width-job">
            <div class="form-box">
                <div class="form-title">
                    <h2><?php the_field('job_form_title_main', 'option') ?></h2>
                    <?php the_field('job_form_title_desc', 'option') ?>
                </div>
                <?php echo do_shortcode('[contact-form-7 id="231" title="Job Form"]') ?>
            </div>
        </div>

    </div>

</div>
     
<?php get_footer(); ?>