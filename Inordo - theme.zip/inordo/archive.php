<?php get_header(); ?>

<div id="wrapp">

    <!-- Blog Content -->
    <div id="blog-content" class="posts-box">
        <div class="container">

            <div class="title big-title text-center">
                <h3>Category: <span><?php single_cat_title(); ?></span></h3>
            </div>
                    
            <?php if(have_posts() ): ?>
                <?php while (have_posts()): ?>
                    <?php the_post(); ?>

                        <div class="single-post">
                            <div class="post-info">
                                <div class="d-flex align-items-center">
                                    <div class="cayrgory box-element">
                                        <?php
                                            $categories = get_the_category(); // Get all categories for the current post
                                            if ($categories) {
                                                $primary_category = $categories[0]; // Get the first category (primary category)
                                                echo '<p><a href="' . get_category_link($primary_category->cat_ID) . '">' . $primary_category->cat_name . '</a></p>';
                                            }
                                        ?>
                                    </div>
                                    <div class="date">
                                        <p><?php echo get_the_date(); ?></p>
                                    </div>
                                </div>
                                <div class="post-name">
                                    <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                        <h3><?php the_title(); ?></h3>
                                    </a>
                                </div>
                            </div>
                            <div class="arrow-link">
                                <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
                                    <img src="<?php echo get_theme_file_uri('./dist/img/circle-black-arrow.svg') ?>" alt="">
                                </a>
                            </div>
                        </div>

                <?php endwhile; else: ?>
            <?php endif; ?>

            <!-- Pagination with numbers -->
            <div class="custom-pagination">
                <?php
                        global $wp_query;
                        $big = 999999999; // need an unlikely integer
                        
                        echo paginate_links( array(
                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'total' => $wp_query->max_num_pages
                        ) );
                    ?>
            </div>

        </div>
        
    </div>
</div>
     
<?php get_footer(); ?>