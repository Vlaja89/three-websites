<footer>
    <div class="top-links">
        <div class="container p-0">
            <div class="top-links-box">
                <?php if( have_rows('top_links', 'option') ): ?>
                    <?php $count = 1 ?>
                    <?php while( have_rows('top_links', 'option') ): the_row(); ?>
                        <div class="single-link" id="link-<?php echo $count; ?>">
                            <p>
                                <a href="<?php the_sub_field('top_links_link', 'option') ?>">
                                    <?php the_sub_field('top_links_title', 'option') ?>
                                </a>
                            </p>
                        </div>
                    <?php $count++; endwhile; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="mid-footer">
        <div class="container">
            <div class="row flex-wrap align-items-start justify-content-center">

                <!-- Col One -->
                <div class="col-lg-4 col-md-12 col-sm-12">
                    <div class="footer-logo">
                        <img src="<?php the_field('footer_logo', 'option') ?>" alt="" class="img-fluid">
                    </div>
                    <div class="footer-desc">
                        <?php the_field('footer_description', 'option') ?>
                    </div>
                    <div class="social-media">
                        <div class="social-title">
                            <p><?php the_field('social_media_title', 'option') ?></p>
                        </div>
                        <?php if( have_rows('social_media', 'option') ): ?>
                            <?php while( have_rows('social_media', 'option') ): the_row(); ?>
                                <div class="single-media">
                                    <a href="<?php the_sub_field('social_media_url', 'option') ?>">
                                        <img src="<?php the_sub_field('social_media_icon', 'option') ?>" alt="">
                                    </a>
                                </div>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Col Two -->
                <div class="offset-lg-2 col-lg-3 col-md-6 col-sm-12">
                    <div class="footer-title">
                        <h5><?php the_field('footer_menu', 'option') ?></h5>
                    </div>
                    <div class="footer-menu">
                        <?php
                            if (has_nav_menu('menu')) {
                                wp_nav_menu(array(
                                    'theme_location' => 'menu',
                                    'menu_class' => 'navbar-nav',
                                    'container' => 'ul'
                                ));
                            }
                        ?>
                    </div>

                </div>

                <!-- Col Three -->
                <div class="col-lg-3 col-md-6 col-sm-12">
                    <div class="footer-title">
                        <h5><?php the_field('footer_title', 'option') ?></h5>
                    </div>
                    <div class="footer-desc">
                        <?php the_field('footer_info', 'option') ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="row flex-wrap align-items-center">
                <div class="col-lg-9 col-md-8 col-sm-12">

                    <div class="copyright-info">
                        <p><?php the_field('copyright_info', 'option') ?></p>
                        <p><span>|</span></p>
                        <?php if( have_rows('copyright_links', 'option') ): ?>
                            <?php while( have_rows('copyright_links', 'option') ): the_row(); ?>
                                <?php 
                                    $link = get_sub_field('copyright_page_url', 'option');
                                    if( $link ): 
                                        $link_url = $link['url'];
                                        $link_title = $link['title'];
                                        ?>
                                        <p><a href="<?php echo esc_url( $link_url ); ?>"><?php echo esc_html( $link_title ); ?></a></p>
                                    <?php endif; ?>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </div>

                </div>
                <div class="col-lg-3 col-md-4 col-sm-12">
                    <div class="copyright-desc">
                        <?php the_field('copyright_creator', 'option') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>

<?php wp_footer(); ?>


</div>
</body>
</html>