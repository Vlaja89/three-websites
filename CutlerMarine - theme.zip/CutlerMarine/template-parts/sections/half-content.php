<?php $Content = get_sub_field('half_description'); ?>

<section id="half-content">
    <div class="container">

        <!-- Links with Section -->
        <div class="row">
            <div class="col-lg-9 col-md-11 col-sm-12">
                <div class="content">
                    <?php if( $Content ): ?>
                        <div class="description">
                            <?php echo $Content ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</section>