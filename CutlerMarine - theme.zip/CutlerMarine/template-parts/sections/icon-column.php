<?php $Title = get_sub_field('icon_column_title'); ?>
<?php $Content = get_sub_field('icon_column_description'); ?>

<section id="icon-column">
    <div class="container">

        <div class="icon-column-title">
            <?php if( $Title ): ?>
                <div class="title text-center">
                    <h3><?php echo $Title ?></h3>
                </div>
            <?php endif; ?>
            <?php if( $Content ): ?>
                <div class="description">
                    <p><?php echo $Content ?></p>
                </div>
            <?php endif; ?>
        </div>

        <div class="icon-column-columns">
            <div class="row flex-wrap align-items-start justify-content-center">
                <?php if( have_rows('icon_columns') ): ?>
                    <?php while( have_rows('icon_columns') ): the_row(); ?>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="single-column">
                                <div class="icon">
                                    <img src="<?php the_sub_field('icon_columns_icon') ?>" alt="" class="img-fluid">
                                </div>
                                <div class="title">
                                    <p><?php the_sub_field('icon_columns_title') ?></p>
                                </div>
                                <div class="description">
                                    <p><?php the_sub_field('icon_columns_description') ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>

