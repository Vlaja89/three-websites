<?php
/**
 * INITIALIZE theme assets
 *
 * @package starter-wp-theme-v2
 */
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'includes.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'cpt.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'tax.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'shortcodes.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'blocks.php';
require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'inits' . DIRECTORY_SEPARATOR . 'enable-blocks.php';

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function the_theme_widgets_init() {
	register_sidebar( array(
		'name'          => 'Sidebar',
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'the_theme_widgets_init' );

// Post thumbnails
add_theme_support('post-thumbnails');

/**
 *  Remove all the filters and actions from
 * the /wp-includes/default-filters.php file 
 **/
	function microdot_remove_emoji_support() {
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_action( 'embed_head', 'print_emoji_detection_script' );
	}
	add_action('init', 'microdot_remove_emoji_support');

	// Remove the `wp_emoji` plugin added to TinyMCE in
	// the /wp-includes/class-wp-editor.php file
	function microdot_remove_emoji_from_tinymce( $plugins ) {
		$key = array_search( 'wpemoji', $plugins );

		if( $key !== false ) {
			unset( $plugins[$key] );
		}

		return $plugins;
	}
	add_filter( 'tiny_mce_plugins', 'microdot_remove_emoji_from_tinymce', 9999, 1 );

	// Removed the DNS prefetch for the Emoji CDN via the filter found in
	// the /wp-includes/general-template.php file
	function microdot_filter_wp_resource_hints( $urls, $relation_type ) {
		if( $relation_type === 'dns-prefetch') {
			$key = array_search( 'https://s.w.org/images/core/emoji/2/svg/', $urls );
			if( $key !== false ) {
				unset( $urls[$key] );
			}
		}

		return $urls;
	}
	add_filter('wp_resource_hints', 'microdot_filter_wp_resource_hints', 999, 2);
	
	
	// Limit except length to 125 characters.
	function get_excerpt( $count ) {
		$permalink = get_permalink($post->ID);
		$excerpt = get_the_content();
		$excerpt = strip_tags($excerpt);
		$excerpt = substr($excerpt, 0, $count);
		$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
		$excerpt = '<p>'.$excerpt.'...</p>';
		return $excerpt;
	}

	// create Theme Settings in ACF
	if( function_exists('acf_add_options_page') ) {

		$parent = acf_add_options_page(array(
			'page_title' 	=> 'Theme General Settings',
			'menu_title'	=> 'Theme Settings',
			'menu_slug' 	=> 'theme-general-settings',
			'capability'	=> 'edit_posts',
			'redirect'		=> false
		));	

		acf_add_options_sub_page(array(
			'page_title'    => 'Footer',
		 	'menu_title'    => 'Footer',
		 	'parent_slug'   => $parent['menu_slug'],
		));

	}

	// ACF title change
	function my_layout_title($title, $field, $layout, $i) {
		if($value = get_sub_field('describe_title')) {
			return $value;
		} else {
			foreach($layout['sub_fields'] as $sub) {
				if($sub['name'] == 'describe_title') {
					$key = $sub['key'];
					if(array_key_exists($i, $field['value']) && $value = $field['value'][$i][$key])
						return $value;
				}
			}
		}
		return $title;
	}
	add_filter('acf/fields/flexible_content/layout_title', 'my_layout_title', 10, 4);


	// Add and Register Menu
	add_theme_support('menus');

	register_nav_menus(
		array(
			'category_menu' => __('Category Menu', 'theme'),
			'register_menu' => __('Register Menu', 'theme'),
			'about_menu' => __('About Menu', 'theme'),
			'terms_menu' => __('Terms Menu', 'theme'),
			'mobile_menu' => __('Mobile Menu', 'theme'),
		)
	);

	// Add Logo inside Appearance
	add_theme_support('custom-logo', array(
		'height' => 38,
		'flex-width' => true,
		'width' => 185,
		'flex-height' => true,
	));

	// Add Logo
	function theme_prefix_the_custom_logo() {
		if (function_exists('the_custom_logo')) {
			the_custom_logo();
		}
	}

	add_filter('get_custom_logo', 'change_logo_class');

	function change_logo_class($html) {
		$html = str_replace('custom-logo-link', 'navbar-brand', $html);
		return $html;
	}


	// SVG - Upload image format in media WP
	function add_file_types_to_uploads($file_types){
		$new_filetypes = array();
		$new_filetypes['svg'] = 'image/svg+xml';
		$file_types = array_merge($file_types, $new_filetypes );
		return $file_types;
	}
	add_filter('upload_mimes', 'add_file_types_to_uploads');


	// Random order by users function
	function my_random_user_query( $class ) {
		if( 'rand' == $class->query_vars['orderby'] )
			$class->query_orderby = str_replace( 'user_login', 'RAND()', $class->query_orderby );

		return $class;
	}
	add_action( 'pre_user_query', 'my_random_user_query' );



	// Hide Login And Display My Account Page after user login
	function hide_login_and_display_account() {
		// Check if the user is logged in
		if (is_user_logged_in()) {
			// Hide login page
			echo '<style>.login-page { display: none !important; }</style>';
		} else {
			// Display account page
			echo '<style>.account-page { display: none !important; }</style>';
		}
	}
	add_action('wp_footer', 'hide_login_and_display_account');

	// Get the primary category from Yoast SEO or fallback to the first selected category
	function get_primary_category($post_id) {
		// Check if Yoast SEO plugin is active
		if (defined('WPSEO_VERSION')) {
			// Get the primary category ID
			$primary_cat_id = get_post_meta($post_id, '_yoast_wpseo_primary_category', true);

			// If primary category is set, return the category object
			if (!empty($primary_cat_id)) {
				return get_term($primary_cat_id, 'category');
			}
		}

		// If Yoast SEO is not active or no primary category found, get the first selected category
		$post_categories = get_the_category($post_id);
		if (!empty($post_categories)) {
			return $post_categories[0];
		}

		// If no categories found, return null
		return null;
	}

	// Get subcategories of the current category
	function get_category_subcategories() {
		// Get the current category
		$category = get_queried_object();

		// Check if the current category has subcategories
		$subcategories = get_categories(array(
			'parent' => $category->term_id,
			'hide_empty' => false // Set to true if you want to hide empty subcategories
		));

		return $subcategories;
	}

	function get_post_tag_slugs() {
		$tags = get_the_tags();
		if (!$tags) {
			return '';
		}
		$tag_slugs = wp_list_pluck($tags, 'slug');
		return implode(',', $tag_slugs);
	}

	// Read time of post
	function estimate_reading_time($post_id) {
		$content = get_post_field('post_content', $post_id);
		$word_count = str_word_count(strip_tags($content));
		$readingtime = ceil($word_count / 400);
	
		return $readingtime;
	}

	// Get first sentence of post
	function get_first_sentence_or_excerpt($content, $excerpt) {
		$content = apply_filters('the_content', $content);
	
		// Match the first paragraph
		$result = preg_match('/<p>(.*?)<\/p>/', $content, $matches);
	
		if ($result) {
			// Get the first paragraph
			$first_paragraph = $matches[1];
	
			// Match the first sentence of the first paragraph
			$result = preg_match('/^([^.!?]*[\.!?]+)(.*)$/', strip_tags($first_paragraph), $matches);
	
			if ($result) {
				return $matches[1];  // Return first sentence of the first paragraph
			}
		}
	
		// If no paragraph or sentence is found, return the excerpt
		return $excerpt;
	}	

	// Ajax calls
	function category_tags_filter(){

		$currTag = $_POST['currTag']; 
		$currCat = $_POST['currCat']; 

		if ( $currCat == '-1' ) {

			$posts_query = new WP_Query(array(
				'post_type' => 'post',
				'posts_per_page' => 15,
				'tag__in' => $currTag,
			));

		} else {

			$posts_query = new WP_Query(array(
				'post_type' => 'post',
				'posts_per_page' => 15,
				'category__in' => $currCat,
				'tag__in' => $currTag,
			));

		}


		
		if ($posts_query->have_posts()) { 
			while ($posts_query->have_posts()) {
				$posts_query->the_post();

			$post_id = get_the_ID();
			$primary_category = get_primary_category($post_id);
		?>

		<div class="single-blog-post col-lg-4 col-md-6 col-sm-12">
			<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
				<div class="small-title">
					<p class="category-article">
						<?php if ($primary_category) { echo $primary_category->name; } ?>
					</p>
					<div class="read-time">
						<p><span>|</span></p>
						<?php 
							$reading_time = estimate_reading_time($post_id);
							if ( $reading_time ) :
						?>
							<p><?php echo $reading_time; ?> min read</p>
						<?php endif; ?>
					</div>
				</div>
				<div class="image">
					<img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title(); ?>" class="img-fluid">
				</div>
				<div class="big-title">
					<h2><?php the_title(); ?></h2>
				</div>
				<div class="date-author">
					<p><?php echo get_the_date(); ?> - 
						<a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">By <?php the_author(); ?></a>
					</p>
				</div>
			</a>
		</div>
			

		<?php 
				} 
			} else { echo '<p class="no-posts">No posts found</p>';
		} wp_reset_postdata(); exit;
	}

	add_action('wp_ajax_category_tags_filter', 'category_tags_filter');
	add_action('wp_ajax_nopriv_category_tags_filter', 'category_tags_filter');
?>




