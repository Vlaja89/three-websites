<?php get_header(); ?>
	
	<?php 
		if (have_posts()) : while (have_posts()) : the_post(); 
			$image_credit = get_field('image_credit');
			$author_id = get_the_author_meta('ID');
			$author_name = get_the_author();
			$coauthors = get_coauthors(); 
	
	?>

		<div class="post-banner container-width">

			<div class="post-banner-box">
                <div class="col-lg-5 col-md-12 col-sm-12">
					
					<div class="image d-991-block">
						<!-- Thumbnail image -->
						<?php if ( has_post_thumbnail() ) { ?>
							<img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title();?>" class="img-fluid">
						<? } else { ?>
							<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
						<?php } ?> 
						<!-- End Thumbnail image --> 
						<?php if ( $image_credit ) : ?>
							<figcaption>
								<p>Image: <?php echo $image_credit; ?></p>
							</figcaption>
						<?php endif; ?>
					</div>

					<div class="single-post-desc">
						<div class="small-title">
							<p class="category-article">
								<?php include 'partials/parts/post-primary-category.php'; ?>
							</p>
						</div>
						<div class="big-title main-post">
							<h1 class="post-font"><?php the_title();?></h1>
						</div>
						<div class="description main-post">
							<h2><?php echo get_first_sentence_or_excerpt(get_the_content(), get_the_excerpt()); ?></h2>
						</div>
						<!-- Display Co Authors -->
						<?php if (!empty($coauthors)) { ?>
							<div class="date-author">
								<p><?php echo get_the_date(); ?> - By

								<?php $author_count = count($coauthors);
								foreach ($coauthors as $index => $coauthor) {
									$author_url = get_author_posts_url($coauthor->ID);

									if ($author_url) {
										echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

										if ($index < $author_count - 1) {
											echo ', ';
										}
									}
								} ?>

								</p>
							</div> 
						<?php } else { ?>
							<div class="date-author">
								<p><?php echo get_the_date(); ?> - By Unknown Author</p>
							</div>
						<?php } ?>
						<!-- End Display Co Authors -->
					</div>

				</div>
                <div class="col-lg-7 col-md-12 col-sm-12 d-991-none">
					<div class="image">
						<!-- Thumbnail image -->
						<?php if ( has_post_thumbnail() ) { ?>
							<img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title();?>" class="img-fluid">
						<? } else { ?>
							<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
						<?php } ?> 
						<!-- End Thumbnail image --> 
						<?php if ( $image_credit ) : ?>
							<figcaption>
								<p>Image: <?php echo $image_credit; ?></p>
							</figcaption>
						<?php endif; ?>
					</div>
				</div>
			</div>


			<!-- Key Points -->
			<?php if( get_field('key_points') ): ?>
				<div class="key-points">
					<div class="key-title blue-box-title">
						<p>key points</p>
					</div>
					<div class="key-points-box">
						<?php if( have_rows('key_points') ): ?> 
							<?php while( have_rows('key_points') ) : the_row(); ?>

								<div class="single-key-box">
									<p><?php the_sub_field('key_points_content'); ?></p>
								</div>

							<?php endwhile; ?>
						<?php endif;?>
					</div>
				</div>
			<?php endif; ?>
			<!-- End Key Points -->

		</div>

		<div class="pdf-post-banner section-width">
			<div class="small-title">
				<p class="category-article">Case Documentation</p>
			</div>
			<div class="big-title">
				<h2><?php the_title();?></h2>
			</div>
		</div>

		<div class="single-post-content">
			<div class="section-width default-post-style">
				<?php the_content(); ?>
			</div>

			<!-- Updated Post -->
			<?php 
				if( get_field('updated_post') ): 
					$update_date = get_field('update_date');
			?>
				<div class="section-width">
					<div class="updated-post">
						<div class="updated-title">
							<p>Updated</p>
						</div>

						<!-- Last time updated posts -->
						<?php if ( $update_date ) : ?>
							<p class="category-article"><?php echo $update_date; ?></p>
						<?php endif; ?>
						<!-- End Last time updated post -->

						<div class="updated-desc">
							<?php the_field('updated_post'); ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- End Updated Post -->

			<div class="section-width share-media">
				<p class="category-article">Share</p>
				<div class="media-icons">
					<a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank"><img src="<?php echo get_theme_file_uri('./assets/images/facebook.svg') ?>" alt=""></a>
					<a href="https://twitter.com/share?url=<?php the_permalink(); ?>" target="_blank"><img src="<?php echo get_theme_file_uri('./assets/images/twitter.svg') ?>" alt=""></a>
					<a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" target="_blank"><img src="<?php echo get_theme_file_uri('./assets/images/linkedin.svg') ?>" alt=""></a>
				</div>
			</div>

		</div>

		<!-- Related Posts -->
		<div class="realted-posts container-width">
			<div class="realted-posts-title blue-box-title">
				<p>related articles</p>
			</div>
			<div class="realted-posts-box">
				<?php $related = get_posts( array( 
					'category__in' => wp_get_post_categories($post->ID), 
					'numberposts' => 4, 
					'post__not_in' => array($post->ID) 
					) 
				);

				if( $related ) foreach( $related as $post ) {
					setup_postdata($post); ?>

					<div class="single-related-post">
						<div class="small-title">
							<p class="category-article">
								<?php include 'partials/parts/post-primary-category.php'; ?>
							</p>
							
							<div class="read-time">
								<p><span>|</span></p>
								<?php 
									$reading_time = estimate_reading_time($post_id);
									if ( $reading_time ) :
								?>
									<p><?php echo $reading_time; ?> min read</p>
								<?php endif; ?>
							</div>
						</div>
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
							<div class="image">
								<!-- Thumbnail image -->
								<?php if ( has_post_thumbnail() ) { ?>
									<img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title();?>" class="img-fluid">
								<? } else { ?>
									<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
								<?php } ?> 
								<!-- End Thumbnail image --> 
							</div>
							
							<div class="big-title">
								<h2><?php the_title();?></h2>
							</div>
						</a>
						<!-- Display Co Authors -->
						<?php $coauthors = get_coauthors(); ?>
							<?php if (!empty($coauthors)) { ?>
								<div class="date-author">
									<p><?php echo get_the_date(); ?> - By

									<?php $author_count = count($coauthors);
									foreach ($coauthors as $index => $coauthor) {
										$author_url = get_author_posts_url($coauthor->ID);

										// Output author name with a link to their profile
										if ($author_url) {
											echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

											// Add a comma and space if there are more authors
											if ($index < $author_count - 1) {
												echo ', ';
											}
										}
									} ?>

									</p>
								</div> 
							<?php } else { ?>
								<div class="date-author">
									<p><?php echo get_the_date(); ?> - By Unknown Author</p>
								</div>
							<?php } ?>
						<!-- End Display Co Authors -->
					</div>
					
				<?php } wp_reset_postdata(); ?>
			</div>
		</div>
		<!-- End Related Posts -->

	<?php endwhile; endif; ?>

<?php get_footer(); ?>