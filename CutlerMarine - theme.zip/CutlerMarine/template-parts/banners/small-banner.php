<?php $Title = get_sub_field('small_banner_title'); ?>
<?php $Content = get_sub_field('small_banner_description'); ?>
<?php $Image = get_sub_field('small_banner_bg_img'); ?>

<section id="small-banner" style="background: url('<?php echo $Image ?>') no-repeat center; background-size: cover">
    <div class="container">
        <div class="row align-items-end">
            <div class="col-lg-5 col-md-10 col-sm-12">

                <div class="banner-title">
                    <?php if( $Title ): ?>
                        <div class="title">
                            <h1><?php echo $Title ?></h1>
                        </div>
                    <?php endif; ?>
                    <?php if( $Content ): ?>
                        <div class="description">
                            <?php echo $Content ?>
                        </div>
                    <?php endif; ?>
                    <?php if( get_sub_field('small_banner_button') ): ?>
                    <!-- Button -->
                        <?php 
                            $link = get_sub_field('small_banner_button');
                            if( $link ): 
                                $link_url = $link['url'];
                                $link_title = $link['title'];
                                ?>
                                <button type="button" class="red-custom-btn" onclick="location.href='<?php echo esc_url( $link_url ); ?>';"><?php echo esc_html( $link_title ); ?></button>
                            <?php endif; ?>
                        <!-- End Button -->
                    <?php endif; ?>
                </div>
                
            </div>
        </div>
    </div>
</section>