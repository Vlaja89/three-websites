<?php $SmallTitle = get_field('contact_small_title', 'option'); ?>
<?php $Title = get_field('contact_main_title', 'option'); ?>
<?php $Desc = get_field('contact_description', 'option'); ?>
<?php $Form = get_field('form', 'option'); ?>

<section id="contact-form">
    <div class="container">

        <div class="row flex-wrap align-items-center">
            <div class="col-lg-5 col-md-12 col-sm-12">
                <div class="contact-info">
                    <?php if( $SmallTitle ): ?>
                        <div class="small-title box-element">
                            <p><?php echo $SmallTitle ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if( $Title ): ?>
                        <div class="title big-title">
                            <h2><?php echo $Title ?></h2>
                        </div>
                    <?php endif; ?>
                    <?php if( $Desc ): ?>
                        <div class="desc">
                            <?php echo $Desc ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="offset-lg-1 col-lg-6 col-md-12 col-sm-12">
                <?php if( $Form ): ?>
                    <div class="form-box">
                        <?php echo $Form ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>
