<?php

    // Case Briefs Block
    $className = 'case_briefs';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $title      = get_field('case_briefs_title');
    $text       = get_field('case_briefs_description');

?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper">
        <div class="holder">
        
            <div class="row-width alphabet">
                <div class="text col-width">
                    <?php if ($title) : ?>
                        <h1><?php echo $title; ?></h1>
                    <?php endif; ?>

                    <?php if ($text) : ?>
                        <h2><?php echo $text; ?></h2>
                    <?php endif; ?>
                </div>

                <div class="content col-width">
                    <?php 
                        $args = array(
                            'post_type'      => 'page',
                            'meta_query'     => array(
                                array(
                                    'key'     => 'page_type', 
                                    'value'   => 'case-briefs',
                                    'compare' => 'LIKE'
                                )
                            ),
                            'orderby'        => 'title',
                            'order'          => 'ASC',
                            'posts_per_page' => -1
                        );
                        
                        $query = new WP_Query($args);
                        
                        $alphabet_pages = array();
                        
                        if ($query->have_posts()) {
                            while ($query->have_posts()) {
                                $query->the_post();
                                $title = get_the_title();
                                $first_letter = strtoupper(substr($title, 0, 1));
                                $slug = get_post_field('post_name', get_the_ID()); 
                                $alphabet_pages[$first_letter][] = array(
                                    'title' => $title,
                                    'slug'  => $slug
                                );
                            }
                        }
                        wp_reset_postdata(); ?>
                        
                    <?php $alphabet = range('A', 'Z'); ?>
                    
                    <div class="page-banner-letters">
                        <?php foreach ($alphabet as $letter): ?>
                            <?php if (isset($alphabet_pages[$letter])): ?>
                                <h6><a href="#<?php echo $letter ?>"><?php echo $letter ?></a></h6>
                            <?php else: ?>
                                <h6><?php echo $letter; ?></h6>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                        
                    <div class="page-content-letter">
                        <?php foreach ($alphabet as $letter) {?> 
                            
                            <div class="single-page-content-letter">
                              <?php  if (isset($alphabet_pages[$letter])) { ?>
                                    <p id="<?php echo $letter ?>" class="letter-position"><?php echo $letter; ?></p>
                                    <h6><?php echo $letter; ?></h6>
                                <?php } else { ?>
                                        <h6><?php echo $letter; ?></h6>
                                <?php } ?>

                                <?php  if (isset($alphabet_pages[$letter])) {
                                    foreach ($alphabet_pages[$letter] as $page) { 
                                        echo '<h2><a href="' . get_permalink() . $page['slug'] . '" target="_blank">' . $page['title'] . '</a></h2>';
                                    }
                                } ?>
                            </div>

                        <?php  } ?>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</section>