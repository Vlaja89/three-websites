<?php $Title = get_sub_field('banner_title_quote_main_title'); ?>
<?php $QuoteTitle = get_sub_field('banner_title_quote_title'); ?>
<?php $QuoteName = get_sub_field('banner_title_quote_name'); ?>

<div id="banner-title-quote">
    <div class="container">

        <div class="row flex-wrap align-items-start justify-content-center">

                <div class="col-lg-6 col-md-12 col-sm-12">
                    <?php if( $Title ): ?>
                        <div class="title big-title">
                            <h2><?php echo $Title ?></h2>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="offset-lg-1 col-lg-5 col-md-12 col-sm-12">
                    <div class="quote-content">
                        <div class="quote-icon">
                            <img src="<?php echo get_theme_file_uri('./dist/img/quote.svg') ?>" alt="">
                        </div>
                        <?php if( $QuoteTitle ): ?>
                            <div class="title">
                                <h4><?php echo $QuoteTitle ?></h4>
                            </div>
                        <?php endif; ?>
                        
                        <?php if( $QuoteName ): ?>
                            <div class="name box-element">
                                <p><?php echo $QuoteName ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

        </div>
        
    </div>
</div>
