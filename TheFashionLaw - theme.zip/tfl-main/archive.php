<?php 
	get_header(); 

	$curr_category = get_queried_object();
	
?>

	<div class="container-width"> 		
		<div class="archive-box">

			<!-- Last Added Post -->
			<?php
				global $wp_query;
				$args = array_merge($wp_query->query_vars, ['posts_per_page' => 1]);
				query_posts($args);
				?>
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div class="archive-main-post">
						<div class="main-post-box">
							<div class="image col-lg-7 col-md-12 col-sm-12">
								<a href="<?php the_permalink() ?>"title="<?php the_title(); ?>">
                                    <!-- Thumbnail image -->
                                    <?php if ( has_post_thumbnail() ) { ?>
                                        <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title();?>" class="img-fluid">
                                    <? } else { ?>
                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
                                    <?php } ?> 
                                    <!-- End Thumbnail image --> 
								</a>
							</div>
							<div class="main-bg-box col-lg-5 col-md-12 col-sm-12">
								<div class="blue-box-title">
									<p>
										<?php echo $curr_category->name; ?> News
									</p>
								</div>
								<div class="archive-post-content">
									<div class="small-title">
										<p class="category-article">
											<?php echo $curr_category->name; ?>
										</p>
									</div>
									<div class="big-title main-post">
										<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
											<h1><?php the_title(); ?></h1>
										</a>
									</div>
									<div class="description">
										<h2><?php echo get_first_sentence_or_excerpt(get_the_content(), get_the_excerpt()); ?></h2>
									</div>
									<!-- Display Co Authors -->
									<?php $coauthors = get_coauthors(); ?>
										<?php if (!empty($coauthors)) { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By

												<?php $author_count = count($coauthors);
												foreach ($coauthors as $index => $coauthor) {
													$author_url = get_author_posts_url($coauthor->ID);

													// Output author name with a link to their profile
													if ($author_url) {
														echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

														// Add a comma and space if there are more authors
														if ($index < $author_count - 1) {
															echo ', ';
														}
													}
												} ?>

												</p>
											</div> 
										<?php } else { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By Unknown Author</p>
											</div>
										<?php } ?>
									<!-- End Display Co Authors -->
								</div>
							</div>
						</div>
					</div>
				<?php endwhile; endif;?>
			<!-- End Last Added Post -->

			<!-- Last Added Post -->
				<?php
					global $wp_query;
					$args = array_merge( $wp_query->query_vars, [
						'posts_per_page' => 4, 
						'offset' => 1
					]);
					query_posts( $args );
				?>
				
				<div class="small-posts">
					<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

						<div class="small-post-box col-lg-3 col-md-6 col-sm-12">
								<div class="small-title">
									<p class="category-article">
										<?php echo $curr_category->name; ?>
									</p>
									<div class="read-time">
										<p><span>|</span></p>
										<?php 
											$reading_time = estimate_reading_time($post_id);
											if ( $reading_time ) :
										?>
											<p><?php echo $reading_time; ?> min read</p>
										<?php endif; ?>
									</div>
								</div>
								<div class="main-bg-box">
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
										<div class="image">
											<!-- Thumbnail image -->
											<?php if ( has_post_thumbnail() ) { ?>
												<img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title();?>" class="img-fluid">
											<? } else { ?>
												<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
											<?php } ?> 
											<!-- End Thumbnail image -->   
										</div>
									</a>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
										<div class="big-title main-post">
											<h2><?php the_title();?></h2>
										</div>
									</a>
									<!-- Display Co Authors -->
									<?php $coauthors = get_coauthors(); ?>
										<?php if (!empty($coauthors)) { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By

												<?php $author_count = count($coauthors);
												foreach ($coauthors as $index => $coauthor) {
													$author_url = get_author_posts_url($coauthor->ID);

													// Output author name with a link to their profile
													if ($author_url) {
														echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

														// Add a comma and space if there are more authors
														if ($index < $author_count - 1) {
															echo ', ';
														}
													}
												} ?>

												</p>
											</div> 
										<?php } else { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By Unknown Author</p>
											</div>
										<?php } ?>
									<!-- End Display Co Authors -->
								</div>
						</div>
								
					<?php endwhile; endif; ?>		
				</div>
			<!-- End Last Added Post -->

			<!-- Category Tabs -->
				<?php $args = array(
					'hide_empty'=> 1,
					'orderby' => 'name',
					'order' => 'ASC'
				); ?>

				<div class="tabs-top">
					<div class="blue-box-title">
						<p>subcategories</p>
						<?php 
							$subcategories = get_category_subcategories();

							if (!empty($subcategories)) :
						?>
						<div class="d-991-none">
							<ul class="cat-tabs" role="tablist">
								<li class="active">
									<a href="#all" data-id="-1" role="tab" class="category-article" data-toggle="tab">All</a>
								</li>

								<?php  foreach ($subcategories as $subcategory) { ?>
									<li>
										<a href="<?php echo get_category_link($subcategory->term_id); ?>" data-id="<?php echo $subcategory->term_id; ?>" class="category-article" role="tab" data-toggle="tab">    
											<?php echo $subcategory->name ?>
										</a>
									</li>
								<?php } ?>

							</ul>
						</div>
						<div class="d-991-block">
							<div class="showBtn">
								<h6 class="category-article">All</h6>
							</div>
							<div class="hideme">
								<ul class="cat-tabs" role="tablist">
									<li class="active">
										<a href="#all" data-id="-1" role="tab" class="category-article" data-toggle="tab">All</a>
									</li>

									<?php  foreach ($subcategories as $subcategory) { ?>
										<li>
											<a href="<?php echo get_category_link($subcategory->term_id); ?>" data-id="<?php echo $subcategory->term_id; ?>" class="category-article" role="tab" data-toggle="tab">    
												<?php echo $subcategory->name ?> 
											</a>
										</li>
									<?php } ?>

								</ul>
							</div>
						</div>
						<?php endif; ?>
						
					</div>
				</div>

				<!-- Post Tags -->
				<div class="post-tags">
					<button type="button" id="toggleButton" class="btn-white-arrow category-article tags-button">
							filter by tags
						<span></span>
					</button>

					<div id="content" class="content-tags">
						<?php $tags = get_tags(); ?>
						<div class="tags">
							<?php foreach ( $tags as $tag ) { ?>
								<div class="single-tag">
									<input type="checkbox" id="<?php echo $tag->slug; ?>" data-tagid="<?php echo $tag->term_id; ?>" name="<?php echo $tag->name; ?>">
									<label for="<?php echo $tag->slug; ?>"><?php echo $tag->name; ?></label>
								</div>
							<?php } ?>
						</div>
						<div class="filter-trigger">
							<button type="button" class="btn-blue tags-trigger" data-category="-1" data-tag="">
								apply filter
							</button>
							<button type="button" class="btn-blue tags-reset" data-category="-1" data-tag="">
								clear filter
							</button>
						</div>
					</div>
				</div>

			<!-- End Category Tabs -->

			<div class="tabs-content">
				<?php
					$paged = (get_query_var('paged')) ? get_query_var('paged') : 1; // Get the current page number
					
				?>

					<!-- All Posts -->
					<div class="tab-pane"> 
						<?php
						$all_posts_query = new WP_Query(array(
							'post_type' => 'post',
							'posts_per_page' => 15,
							'paged' => $paged, // Set the current page
							'category__in' => $curr_category->term_id
						));

						while ($all_posts_query->have_posts()) :
							$all_posts_query->the_post();
							?>

							<div class="single-blog-post col-lg-4 col-md-6 col-sm-12">
									<div class="small-title">
										<p class="category-article">
											<?php echo $curr_category->name; ?>
										</p>
										<div class="read-time">
											<p><span>|</span></p>
											<?php 
												$reading_time = estimate_reading_time($post_id);
												if ( $reading_time ) :
											?>
												<p><?php echo $reading_time; ?> min read</p>
											<?php endif; ?>
										</div>
									</div>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
										<div class="image">
											<!-- Thumbnail image -->
											<?php if ( has_post_thumbnail() ) { ?>
												<img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title();?>" class="img-fluid">
											<? } else { ?>
												<img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
											<?php } ?> 
											<!-- End Thumbnail image -->   
										</div>
									</a>
									<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">
										<div class="big-title main-post">
											<h2><?php the_title(); ?></h2>
										</div>
									</a>
									<!-- Display Co Authors -->
									<?php $coauthors = get_coauthors(); ?>
										<?php if (!empty($coauthors)) { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By

												<?php $author_count = count($coauthors);
												foreach ($coauthors as $index => $coauthor) {
													$author_url = get_author_posts_url($coauthor->ID);

													// Output author name with a link to their profile
													if ($author_url) {
														echo '<a href="' . esc_url($author_url) . '">' . esc_html($coauthor->display_name) . '</a>';

														// Add a comma and space if there are more authors
														if ($index < $author_count - 1) {
															echo ', ';
														}
													}
												} ?>

												</p>
											</div> 
										<?php } else { ?>
											<div class="date-author">
												<p><?php echo get_the_date(); ?> - By Unknown Author</p>
											</div>
										<?php } ?>
									<!-- End Display Co Authors -->
								</a>
							</div>

						<?php endwhile; ?>

						<!-- Pagination -->
						<?php
						$total_pages = $all_posts_query->max_num_pages; // Get the total number of pages
						if ($total_pages > 1) {
							?>
							<div class="custom-pagination">
								<?php
								echo paginate_links(array(
									'base' => get_pagenum_link(1) . '%_%',
									'format' => '/page/%#%', // Custom pagination format
									'current' => $paged,
									'total' => $total_pages,
									'prev_text' => __('<img src="/wp-content/uploads/2023/07/blue-arrow-left.svg" alt="">'),
									'next_text' => __('<img src="/wp-content/uploads/2023/07/blue-arrow-right.svg" alt="">'),
								));
								?>
							</div>
						<?php } ?>
					</div>
					<!-- End All Posts -->

				<?php ?>
			</div>

		</div>
	</div>

<?php get_footer(); ?>