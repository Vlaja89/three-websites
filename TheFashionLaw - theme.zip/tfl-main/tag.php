<?php get_header(); ?>

<div class="wrapper">
    <div class="holder">

        <div class="linear-content container-width"> 	
            
            <!-- Tags Content -->
            <div class="linear-box">
                <div class="blue-box-title">
                    <p><?php single_tag_title( 'Tag: ', true ); ?></p>
                </div>
                <?php
                    global $wp_query;
                    $args = array_merge( $wp_query->query_vars, ['post_type' => 'post' ] );
                    query_posts( $args );
                ?>
                <?php if(have_posts() ): ?>
                    <?php while (have_posts()): ?>
                    <?php the_post(); ?>

                        <div class="single-blog-post">
                            <div class="linear-single-content">
                                <div class="small-title">
                                    <p class="category-article">
                                        <?php include 'partials/parts/post-primary-category.php'; ?>
                                    </p>
                                </div>
                                <div class="image d-991-block">
                                    <a href="<?php the_permalink() ?>" itle="<?php the_title(); ?>">
                                        <!-- Thumbnail image -->
                                        <?php if ( has_post_thumbnail() ) { ?>
                                            <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title();?>" class="img-fluid">
                                        <? } else { ?>
                                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
                                        <?php } ?> 
                                        <!-- End Thumbnail image -->   
                                    </a>
                                </div>
								<a href="<?php the_permalink() ?>" itle="<?php the_title(); ?>">
                                    <div class="big-title main-post">
                                        <h1><?php the_title(); ?></h1>
                                    </div> 
                                </a>
                                <div class="date-author">
                                    <p><?php echo get_the_date(); ?> - 
                                        <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">By <?php the_author(); ?></a>
                                    </p>
                                </div>
                            </div>
                            <div class="image d-991-none">
                                <a href="<?php the_permalink() ?>" itle="<?php the_title(); ?>">
                                    <!-- Thumbnail image -->
                                    <?php if ( has_post_thumbnail() ) { ?>
                                        <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title();?>" class="img-fluid">
                                    <? } else { ?>
                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/default-thumbnail.jpg" alt="<?php the_title(); ?>" class="img-fluid"/>
                                    <?php } ?> 
                                    <!-- End Thumbnail image -->   
                                </a>
                            </div>
                        </div>

                <?php endwhile; else: ?>
            </div>

            <!-- If there no have search results display this message. Before adding this, you must create a new template in includes folder (section-searchresults.php). Copy and past whole code from Acrhive template and change the root  -->
            <div class="no-results">
                <p><strong>There are no search Results for <span style="color: #C9433C;">'<?php the_search_query(); ?>'</span></strong></p>
            </div>
                    
            <?php endif; ?>
            
            <!-- Pagination with numbers -->
            <div class="custom-pagination">
                <?php
                        global $wp_query;
                        $big = 999999999; // need an unlikely integer
                        
                        echo paginate_links( array(
                            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                            'format' => '?paged=%#%',
                            'current' => max( 1, get_query_var('paged') ),
                            'prev_text' => __('<img src="/wp-content/uploads/2023/06/blue-arrow-left.svg" alt="">'),
                            'next_text' => __('<img src="/wp-content/uploads/2023/06/blue-arrow-right.svg" alt="">'),
                            'total' => $wp_query->max_num_pages
                        ) );
                    ?>
            </div>
        </div>

    </div>
</div>

     
<?php get_footer(); ?>

                           
