<?php

    /**
    * Allow/Enable ACF blocks
    */

    function my_allowed_block_types($allowed_blocks, $post) {
        // If current post type is 'page', return an empty array to disable all blocks
        if ($post->post_type === 'page') {
            return array(
                'acf/hero',
                'acf/count-columns', 
                'acf/textual-editor',
                'acf/banner',
                'acf/line-divider',
                'acf/list-text',
                'acf/spacer',
                'acf/quote',
                'acf/text-expander',
                'acf/text-image',
                'acf/small-title-and-description', 
                'acf/year-month-subscribe', 
                'acf/title-and-description', 
                'acf/blue-green-box', 
                'acf/faq', 
                'acf/student-subscriptions', 
                'acf/daily-links', 
                'acf/proprietary-data-sets', 
                'acf/deep-dives', 
                'acf/weekly-briefings', 
                'acf/case-documentation', 
                'acf/reports-trackers', 
                'acf/case-briefs', 
                'acf/topics-of-interest',
                'acf/case-documentation-content', 
                'core/html',
            ); 
        }
    
        // Otherwise, return the full list of allowed blocks
        return $allowed_blocks;
    }
    add_filter('allowed_block_types', 'my_allowed_block_types', 10, 2);
    