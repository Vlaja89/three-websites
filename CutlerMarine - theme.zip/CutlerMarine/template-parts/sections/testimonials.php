<?php $Title = get_sub_field('testimonials_title'); ?>
<?php $Image = get_sub_field('testimonials_description'); ?>

<section id="testimonials">
    <div class="container">

        <?php if( $Title ): ?>
            <div class="title text-center">
                <h3><?php echo $Title ?></h3>
            </div>
        <?php endif; ?>

        <div class="testimonials-box row flex-wrap align-items-start justify-content-center">
            <?php
                $testimonials = get_sub_field('testimonial');
                if( $testimonials ): ?>
                    <?php $count = 1 ?>
                    <?php foreach( $testimonials as $post ): 

                        // Setup this post for WP functions (variable must be named $post).
                        setup_postdata($post); ?>
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="single-testimonial-box" id="test-box-<?php echo $count; ?>">
                                <div class="testimonial-initials">
                                    <p><?php the_field('testimonial_initials'); ?></p>
                                </div>
                                <div class="testimonial-content">
                                    <div class="quote-icon">
                                        <img src="<?php echo get_theme_file_uri('./dist/img/quote.svg') ?>" alt="">
                                    </div>
                                    <div class="testimonial-desc">
                                        <p><?php the_field('testimonial_description'); ?></p>
                                    </div>
                                    <div class="testimonial-name">
                                        <p><?php the_title(); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php $count++; endforeach; ?>
                <?php 
                // Reset the global post object so that the rest of the page works correctly.
                wp_reset_postdata(); ?>
            <?php endif; ?>
        </div>

    </div>
</section>