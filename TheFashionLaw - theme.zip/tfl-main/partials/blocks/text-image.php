<?php

    // Text Image Columns Block
    $className = 'text_image';
    if (!empty($block['className'])) {
        $className .= ' ' . $block['className'];
    }

    if (!empty($block['align'])) {
        $className .= ' align' . $block['align'];
    }

    $block_width = get_field('block_width');
    $subtitle   = get_field('subtitle');
    $title      = get_field('title');
    $text       = get_field('text');
    $image      = get_field('image');

    // Editor in chief. Ovo cemo naknadno da ubacimo za width blokova
?>

<section class="<?php echo esc_attr($className); ?>">
    <div class="wrapper <?php echo $block_width; ?>">
        <div class="holder">

            <div class="text-image-box">
                <div class="col-lg-6 col-md-12 col-sm-12">
                    <div class="text">
                        <?php if ($subtitle) : ?>
                            <div class="small-title">
                                <p class="category-article"><?php echo $subtitle; ?></p>
                            </div>
                        <?php endif; ?>

                        <?php if ($title) : ?>
                            <div class="big-title">
                                <h1><?php echo $title; ?></h1>
                            </div>
                        <?php endif; ?>

                        <div class="image d-991-block">
                            <?php if( !empty($image) ): ?>
                                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img-fluid"/>
                                <figcaption>
                                    <p><?php echo esc_html($image['caption']); ?></p>
                                </figcaption>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ( $text ) : ?>
                            <div class="description font-19">
                                <?php echo $text; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 d-991-none">
                    <div class="image">
                        <?php if( !empty($image) ): ?>
                            <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" class="img-fluid"/>
                            <figcaption>
                                <p><?php echo esc_html($image['caption']); ?></p>
                            </figcaption>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section><!-- Text & Image Columns -->