<?php $Title = get_sub_field('service_main_title'); ?>

<section id="our-services">
    <div class="container">

        <?php if( $Title ): ?>
            <div class="title big-title text-center">
                <h3><?php echo $Title ?></h3>
            </div>
        <?php endif; ?>

        <div class="service-boxes">
            <div class="row flex-wrap align-items-start justify-content-center">
                <?php if( have_rows('services') ): ?>
                    <?php $count = 1; ?>
                    <?php while( have_rows('services') ): the_row(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <div class="single-service">
                                <div class="icon">
                                    <img src="<?php the_sub_field('service_icon') ?>" alt="" class="img-fluid">
                                </div>
                                <div class="service-desc">
                                    <div class="d-flex align-items-start">
                                        <div class="number">
                                            <p><?php echo str_pad($count, 2, '0', STR_PAD_LEFT); ?></p>
                                        </div>
                                        <div class="title">
                                            <h3><?php the_sub_field('service_title') ?></h3>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <p><?php the_sub_field('service_description') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php $count++; endwhile; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>

